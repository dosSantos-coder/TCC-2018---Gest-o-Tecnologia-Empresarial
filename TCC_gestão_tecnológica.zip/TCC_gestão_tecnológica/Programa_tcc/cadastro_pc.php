<?php
   include("conexao.php");
   session_start();
try{
	   $nome_pc = $_POST['n_pc'];
	   $departamento = $_POST['departamento'];
	   $IP = $_POST['ip'];
	   $HD = $_POST['hd'];
	   $memoria_ram = $_POST['memoria_ram'];
	   $processador = $_POST['processador'];
     
      if($nome_pc == "" || $departamento == "" || $IP == "" || $memoria_ram == "" || $processador == "" || $HD == "" || $processador == ""){
             
             echo "vazio";
	   }else{
	   
	 if(isset($_FILES['img']['name']) && $_FILES['img']['error'] == 0){
		$formatosP = array("png","jpeg","jpg","gif");
		$extencao = pathinfo($_FILES['img']['name'],PATHINFO_EXTENSION);

		if(in_array($extencao,$formatosP)){
	        echo $_FILES['img']['name'];
		    $novo_nome = md5(time()).$extencao;
		    $diretorio = "img/";
		    move_uploaded_file($_FILES['img']['tmp_name'], $diretorio.$novo_nome);

	       }else{
	           echo $_SESSION['img_invalida'] = "invalido";
            }
        }else{
       		$novo_nome ="";
        }
	  
          
	      $query = "INSERT INTO TB_CONTROLE_M(IP,NOME_PC,DEPARTAMENTO,HD,MEMORIA,PROCESSADOR,imagem_pc)VALUES(?,?,?,?,?,?,?)";
	      $sql = $con->prepare($query);
	      $sql->bindValue(1,$IP);
	      $sql->bindValue(2,$nome_pc);
	      $sql->bindValue(3,$departamento);
	      $sql->bindValue(4,$HD);
	      $sql->bindValue(5,$memoria_ram);
	      $sql->bindValue(6,$processador);
	      $sql->bindValue(7,$novo_nome);
	      $sql->execute();
          echo "cadastrado com sucesso";
    }
	 
}
catch(Exception $e){
     echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
}






 // if(isset($_FILES['img']['name']) && $_FILES['img']['error'] == 0){
		
	// 	$extencao = strtolower(substr($_FILES['img']['name'],-4));
	//     $novo_nome = md5(time()).$extencao;
	//     $diretorio = "img/";
	//     move_uploaded_file($_FILES['img']['tmp_name'], $diretorio.$novo_nome);


 //        }
 //        else{
 //       		$novo_nome ="";
 //        }


	?>
