<!DOCTYPE html>
<html>
    <header>
        <?php
	       include("conexao.php");
            session_start();
            if(!isset($_SESSION['logado'])){
              header("location:index.php");
            }

	   ?>
	       <title>Funcionário</title>
	       <link href="css/uikit.min.css" rel="stylesheet">
           <style type="text/css">
                 footer {
                      background-color: rgb(0, 55, 96);
                      display: block;
                      min-height: 140px;
                      width: 100%;
                }
           </style>
    </header>

    <body>
        <div class="uk-section-primary uk-preserve-color">

        <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

        <nav class="uk-navbar-container" uk-navbar>
                <div class="uk-navbar-left">

                    <ul class="uk-navbar-nav">
                        <li class="uk-active"><a href="#">Home</a></li>
                        <li><a href="Tela_Enviar_os.php">Relatar Casos</a></li>
                    </ul>

                </div>
                 <div class="uk-navbar-center">
             <br>
                    <h4>Olá <?php echo $_SESSION["nome"]." ".$_SESSION['sobrenome'];?></h4>
                
             </div>
                <div class="uk-navbar-right">

                    <ul class="uk-navbar-nav">
                        
                        <li>
                            <a  href="#">Configurações</a>
                        <div class="uk-navbar-dropdown">
                            <ul class="uk-nav uk-navbar-dropdown-nav">
                                <li class="uk-active"><a href="#">configurações gerais</a></li>
                                <li><a href="troca_senha.php">Seu perfil</a></li>
                                <li class="uk-nav-divider"></li>
                                <li><a href="sair.php">Sair</a></li>
                            </ul>
                        </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div><br>
         <?php
          $id_p = $_SESSION['ID']; 
          $sql = $con->prepare("SELECT * from TB_os os  where ID_MANDO = '$id_p' order by  ID desc ");
          $sql->execute();?>
        <div class="uk-card uk-card-default uk-card-body uk-width-3-2@m">
            <div class="uk-card-badge uk-label"><?php echo $sql->rowCount();?> Relatos </div>
            <h3 class="uk-card-title">Seus relatos</h3>
            <center>
                <?php if(isset($_SESSION["alterar_r"])){
                                    echo
                                    '<div class="uk-alert-success" style ="width:400px;" uk-alert>
                                          <a class="uk-alert-close" uk-close></a>
                                           <p>✔ '.$_SESSION['alterar_r'].'</p>
                                    </div>';
                                    unset($_SESSION['alterar_r']);
                                 } ?>
            </center>
            <table class="uk-table uk-table-responsive uk-table-divider">
                <thead>
                    <tr>
                        <th>Hora e data</th>
                        <th>Titulo</th>
                        <th>Departamento</th>
                        <th>Mais informações</th>
                        <th>alterar relato</th>
                        <th>Excluir relato</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <?php while ($linha_r = $sql->fetch()) { ?>
                <tbody>
                    <tr>
                    <?php if($linha_r['STATUS_ERRO'] == 0){ ?>
                        <td><?php echo $linha_r['DATA_ENVIO'].'<br>'.$linha_r['HORA_ENVIO']; ?></td>
                        <td><?php echo $linha_r['TITULO'];?></td>
                        <td><?php echo $linha_r['DEPARTAMENTO'];?></td>
                        <td>
                            <a class="uk-button uk-button-default" href="#modal-overflow<?php echo $linha_r['ID'];?>" uk-toggle>Informações</a>
                            <div id="modal-overflow<?php echo $linha_r['ID'];?>" uk-modal>
                                <div class="uk-modal-dialog">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header">
                                        <h2 class="uk-modal-title">Informações</h2>
                                    </div>
                                    <div class="uk-modal-body" uk-overflow-auto>
                                        <div>
                                            <div class="uk-card uk-card-primary uk-card-body">
                                                <h3 class="uk-card-title">Titulo: <?php echo $linha_r['TITULO'];?></h3>
                                                <h4 style="display: inline;">Em processo Por:</h4> <p style="display: inline;"><?php echo strtoupper($linha_r['nome_pego']);?></p><br>
                                                <h4 style="display: inline;">Departamento:</h4> <p style="display: inline;"><?php echo $linha_r['DEPARTAMENTO'];?></p><br>
                                                <h4 style="display: inline;">Gravidade:</h4> <p style="display: inline;"><?php echo $linha_r['GRAVIDADE'];?></p><br>
                                                <h4 style="display: inline;">Ramal:</h4> <p style="display: inline;"><?php echo $linha_r['RAMAL'];?></p><br>
                                               <h4 style="display: inline;">Frequecia:</h4> <p style="display: inline;"><?php echo $linha_r['FREQUECIA'];?></p><br>
                                               <h4 style="display: inline;">Versão:</h4> <p style="display: inline;"><?php echo $linha_r['VERSAO'];?></p><br>
                                               <h4 style="display: inline;">Descrição:</h4> <p style="display: inline;"><?php echo $linha_r['DESCRICAO'];?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-modal-footer uk-text-right">
                                  <button class="uk-button uk-button-default uk-modal-close" type="button">Sair</button>
                            </div>
                        </td>
                        <td>
                            <a  class="uk-button uk-button-default" href="#modal-alterar<?php echo $linha_r['ID']; ?>" uk-toggle>Alterar</a>
                                <div id="modal-alterar<?php echo $linha_r['ID']; ?>" uk-modal>
                                    <div class="uk-modal-dialog">
                                        <button class="uk-modal-close-default" type="button" uk-close></button>
                                        <div class="uk-modal-header">
                                            <h2 class="uk-modal-title">Alterar</h2>
                                        </div>
                                        <div class="uk-modal-body" uk-overflow-auto>
                                            <form class="uk-form-stacked" action="alterar_relato.php" method="POST">
                                                <input type="hidden"  name="id" id="<?php $linha_r['ID'];?>" value ="<?php echo $linha_r['ID'];?>">
                                                <div class="uk-margin">
                                                    <label class="uk-form-label" for="form-stacked-text">Titulo</label>
                                                    <div class="uk-form-controls">
                                                        <input class="uk-input" name="titulo" type="text" value="<?php echo $linha_r['TITULO']; ?>">
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                    <label class="uk-form-label" for="form-stacked-text">Ramal</label>
                                                    <div class="uk-form-controls">
                                                        <input class="uk-input" name="ramal" type="text" value="<?php echo $linha_r['RAMAL']; ?>">
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                    <label class="uk-form-label" for="form-stacked-text">Versão</label>
                                                    <div class="uk-form-controls">
                                                        <input class="uk-input" name="versao" type="text" value="<?php echo $linha_r['VERSAO']; ?>">
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                    <label class="uk-form-label" for="form-stacked-text">Descrição</label>
                                                    <div class="uk-form-controls">
                                                      
                                                        <textarea class="uk-input" name="desc" type="text" placeholder="<?php echo $linha_r['DESCRICAO']; ?>"></textarea>
                                                   </div>
                                                </div>
                                               <div class="uk-margin">
                                                     <div class="uk-form-controls">
                                                         <div class="uk-margin">
                                                            <select class="uk-select" id="gravidade" name="gravidade">
                                                                <option>Normal</option>
                                                                <option>Urgente</option>
                                                            </select>
                                                         </div>
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                     <div class="uk-form-controls">
                                                         <div class="uk-margin">
                                                            <select class="uk-select" id="frequecia" name="Frequecia">
                                                                <option>Esporadicamente</option>
                                                                <option>Ocasionalmante</option>
                                                                <option>Sempre</option>
                                                            </select>
                                                         </div>
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                     <div class="uk-form-controls">
                                                         <div class="uk-margin">
                                                            <select class="uk-select" id="departamento" name="departamento">
                                                                <option>Finaceiro</option>
                                                                <option>Administração</option>
                                                                <option>RH</option>
                                                            </select>
                                                         </div>
                                                   </div>
                                                </div>
                                            </div>
                                            <div class="uk-modal-footer uk-text-right">
                                                <button class="uk-button uk-button-default uk-modal-close" type="button">Cancelar</button>
                                                <input type="submit" name="" class="uk-button uk-button-primary" value="alterar">
                                            </div>
                                    </form>
                        </td>
                        <td>
                            <button class="uk-button uk-button-default" id="excluir" href="#modal-excluir<?php echo $linha_r['ID']; ?>"  uk-toggle disabled>Excluir</button>
                            <div id="modal-excluir<?php echo $linha_r['ID']; ?>" uk-modal>
                                <div class="uk-modal-dialog">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header" style="background-color: red;">
                                        <h2 class="uk-modal-title" style="color: #fff;">Tem certeza que dejesa excluir</h2>
                                    </div>
                                    <div class="uk-modal-body">
                                        <center>
                                            <form action="Excluir_relato.php" method="POST">
                                            <input type="hidden"  name="id" id="<?php echo  $linha_r['ID']; ?>" value ="<?php echo $linha_r['ID']; ?>">
                                            <button class="uk-button uk-button-Secondary uk-modal-close uk-button-large uk-width-1-3" type="button">Cancelar</button>
                                            <button class="uk-button uk-button-primary uk-button-large uk-width-1-3" type="submit">Excluir</button>
                                        </center>
                                    </div>
                                </form>
                            </div>
                        </div>
                        </td>
                        <td class="column10"><div uk-tooltip="title: Em execução; pos: right" style=" border-radius: 100%; border:10px solid yellow ;  border-width: 10px; width: 4px;"></div></td>
                    <?php }?>
                    <?php if($linha_r['STATUS_ERRO'] == 1){ ?>
                        <td><?php echo $linha_r['DATA_ENVIO'].'<br>'.$linha_r['HORA_ENVIO']; ?></td>
                        <td><?php echo $linha_r['TITULO'];?></td>
                        <td><?php echo $linha_r['DEPARTAMENTO'];?></td>
                        <td>
                            <a class="uk-button uk-button-default" href="#modal-overflow<?php echo $linha_r['ID'];?>" uk-toggle>Informações</a>
                            <div id="modal-overflow<?php echo $linha_r['ID'];?>" uk-modal>
                                <div class="uk-modal-dialog">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header">
                                        <h2 class="uk-modal-title">Informações</h2>
                                    </div>
                                    <div class="uk-modal-body" uk-overflow-auto>
                                        <div>
                                            <div class="uk-card uk-card-primary uk-card-body">
                                                <h3 class="uk-card-title">Titulo: <?php echo $linha_r['TITULO'];?></h3>
                                                <h4 style="display: inline;">Resolvido Por:</h4> <p style="display: inline;"><?php echo strtoupper($linha_r['nome_pego']);?></p><br>
                                                <h4 style="display: inline;">Departamento:</h4> <p style="display: inline;"><?php echo $linha_r['DEPARTAMENTO'];?></p><br>
                                                <h4 style="display: inline;">Gravidade:</h4> <p style="display: inline;"><?php echo $linha_r['GRAVIDADE'];?></p><br>
                                                <h4 style="display: inline;">Ramal:</h4> <p style="display: inline;"><?php echo $linha_r['RAMAL'];?></p><br>
                                               <h4 style="display: inline;">Frequecia:</h4> <p style="display: inline;"><?php echo $linha_r['FREQUECIA'];?></p><br>
                                               <h4 style="display: inline;">Versão:</h4> <p style="display: inline;"><?php echo $linha_r['VERSAO'];?></p><br>
                                               <h4 style="display: inline;">Descrição:</h4> <p style="display: inline;"><?php echo $linha_r['DESCRICAO'];?></p><br>
                                               <h4 style="display: inline;">Relatorio:</h4> <p style="display: inline;"><?php echo $linha_r['RESUMO'];?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-modal-footer uk-text-right">
                                  <button class="uk-button uk-button-default uk-modal-close" type="button">Sair</button>
                            </div>
                        </td>
                        <td><button class="uk-button uk-button-default" disabled>alterar</button></td>
                        <td>
                            <button class="uk-button uk-button-default" id="excluir" href="#modal-excluir<?php echo $linha_r['ID']; ?>" uk-toggle disabled>Excluir</button>
                            <div id="modal-excluir<?php echo $linha_r['ID']; ?>" uk-modal>
                                <div class="uk-modal-dialog">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header" style="background-color: red;">
                                        <h2 class="uk-modal-title" style="color: #fff;">Tem certeza que dejesa excluir</h2>
                                    </div>
                                    <div class="uk-modal-body">
                                        <center>
                                            <form action="Excluir_relato.php" method="POST">
                                            <input type="hidden"  name="id" id="<?php echo  $linha_r['ID']; ?>" value ="<?php echo $linha_r['ID']; ?>">
                                            <button class="uk-button uk-button-Secondary uk-modal-close uk-button-large uk-width-1-3" type="button">Cancelar</button>
                                            <button class="uk-button uk-button-primary uk-button-large uk-width-1-3" type="submit">Excluir</button>
                                        </center>
                                    </div>
                                </form>
                            </div>
                        </div>
                        </td>
                       <td class="column10"><div uk-tooltip="title: Concluido; pos: right"  style=" border-radius: 100%; border:10px solid green;  border-width: 10px; width: 4px;"></div></td>
                    <?php }?>
                    <?php if($linha_r['STATUS_ERRO'] == 2){ ?>
                        <td><?php echo $linha_r['DATA_ENVIO'].'<br>'.$linha_r['HORA_ENVIO']; ?></td>
                        <td><?php echo $linha_r['TITULO'];?></td>
                        <td><?php echo $linha_r['DEPARTAMENTO'];?></td>
                         <td>
                          <a class="uk-button uk-button-default" href="#modal-overflow<?php echo $linha_r['ID'];?>" uk-toggle>Informações</a>
                            <div id="modal-overflow<?php echo $linha_r['ID'];?>" uk-modal>
                                <div class="uk-modal-dialog">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header">
                                        <h2 class="uk-modal-title">Informações</h2>
                                    </div>
                                    <div class="uk-modal-body" uk-overflow-auto>
                                        <div>
                                            <div class="uk-card uk-card-primary uk-card-body">
                                                <h3 class="uk-card-title">Titulo: <?php echo $linha_r['TITULO'];?></h3>
                                                <h4 style="display: inline;">Resolvido Por:</h4> <p style="display: inline;"><?php echo strtoupper($linha_r['nome_pego']);?></p><br>
                                                <h4 style="display: inline;">Departamento:</h4> <p style="display: inline;"><?php echo $linha_r['DEPARTAMENTO'];?></p><br>
                                                <h4 style="display: inline;">Gravidade:</h4> <p style="display: inline;"><?php echo $linha_r['GRAVIDADE'];?></p><br>
                                                <h4 style="display: inline;">Ramal:</h4> <p style="display: inline;"><?php echo $linha_r['RAMAL'];?></p><br>
                                               <h4 style="display: inline;">Frequecia:</h4> <p style="display: inline;"><?php echo $linha_r['FREQUECIA'];?></p><br>
                                               <h4 style="display: inline;">Versão:</h4> <p style="display: inline;"><?php echo $linha_r['VERSAO'];?></p><br>
                                               <h4 style="display: inline;">Descrição:</h4> <p style="display: inline;"><?php echo $linha_r['DESCRICAO'];?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-modal-footer uk-text-right">
                                  <button class="uk-button uk-button-default uk-modal-close" type="button">Sair</button>
                            </div>
                                </td>
                        
                         <td>
                            <a  class="uk-button uk-button-default" href="#modal-alterar<?php echo $linha_r['ID']; ?>" uk-toggle>Alterar</a>
                                <div id="modal-alterar<?php echo $linha_r['ID']; ?>" uk-modal>
                                    <div class="uk-modal-dialog">
                                        <button class="uk-modal-close-default" type="button" uk-close></button>
                                        <div class="uk-modal-header">
                                            <h2 class="uk-modal-title">Alterar</h2>
                                        </div>
                                        <div class="uk-modal-body" uk-overflow-auto>
                                            <form class="uk-form-stacked" action="alterar_relato.php" method="POST">
                                                <input type="hidden"  name="id" id="<?php $linha_r['ID'];?>" value ="<?php echo $linha_r['ID'];?>">
                                                <div class="uk-margin">
                                                    <label class="uk-form-label" for="form-stacked-text">Titulo</label>
                                                    <div class="uk-form-controls">
                                                        <input class="uk-input" name="titulo" type="text" value="<?php echo $linha_r['TITULO']; ?>">
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                    <label class="uk-form-label" for="form-stacked-text">Ramal</label>
                                                    <div class="uk-form-controls">
                                                        <input class="uk-input" name="ramal" type="text" value="<?php echo $linha_r['RAMAL']; ?>">
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                    <label class="uk-form-label" for="form-stacked-text">Versão</label>
                                                    <div class="uk-form-controls">
                                                        <input class="uk-input" name="versao" type="text" value="<?php echo $linha_r['VERSAO']; ?>">
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                    <label class="uk-form-label" for="form-stacked-text">Descrição</label>
                                                    <div class="uk-form-controls">
                                                      
                                                        <textarea class="uk-input" name="desc" type="text" value="<?php echo $linha_r['DESCRICAO']; ?>"></textarea>
                                                   </div>
                                                </div>
                                               <div class="uk-margin">
                                                     <div class="uk-form-controls">
                                                         <div class="uk-margin">
                                                            <select class="uk-select" id="gravidade" name="gravidade">
                                                                <option>Normal</option>
                                                                <option>Urgente</option>
                                                            </select>
                                                         </div>
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                     <div class="uk-form-controls">
                                                         <div class="uk-margin">
                                                            <select class="uk-select" id="frequecia" name="Frequecia">
                                                                <option>Esporadicamente</option>
                                                                <option>Ocasionalmante</option>
                                                                <option>Sempre</option>
                                                            </select>
                                                         </div>
                                                   </div>
                                                </div>
                                                <div class="uk-margin">
                                                     <div class="uk-form-controls">
                                                         <div class="uk-margin">
                                                            <select class="uk-select" id="departamento" name="departamento">
                                                                <option>Finaceiro</option>
                                                                <option>Administração</option>
                                                                <option>RH</option>
                                                            </select>
                                                         </div>
                                                   </div>
                                                </div>
                                            </div>
                                            <div class="uk-modal-footer uk-text-right">
                                                <button class="uk-button uk-button-default uk-modal-close" type="button">Cancelar</button>
                                                <input type="submit" name="" class="uk-button uk-button-primary" value="alterar">
                                            </div>
                                    </form>
                                </td>
                               
                            <td>
                            <a class="uk-button uk-button-default" id="excluir" href="#modal-excluir<?php echo $linha_r['ID']; ?>" uk-toggle>Excluir</a>
                            <div id="modal-excluir<?php echo $linha_r['ID']; ?>" uk-modal>
                                <div class="uk-modal-dialog">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header" style="background-color: red;">
                                        <h2 class="uk-modal-title" style="color: #fff;">Tem certeza que dejesa excluir</h2>
                                    </div>
                                    <div class="uk-modal-body">
                                        <center>
                                            <form action="Excluir_relato.php" method="POST">
                                            <input type="hidden"  name="id" id="<?php echo  $linha_r['ID']; ?>" value ="<?php echo $linha_r['ID']; ?>">
                                            <button class="uk-button uk-button-Secondary uk-modal-close uk-button-large uk-width-1-3" type="button">Cancelar</button>
                                            <button class="uk-button uk-button-primary uk-button-large uk-width-1-3" type="submit">Excluir</button>
                                        </center>
                                    </div>
                                </form>
                            </div>
                        </div>
                        </td>
                       <td class="column10"><div uk-tooltip="title: Não pego; pos: right"  style=" border-radius: 100%; border:10px solid red;  border-width: 10px; width: 4px;"></div></td>
                    <?php }?>
                </tr>
            </tbody>
              <?php } ?>
            </table>
        </div><br>
       
		

        <script type="text/javascript" src="js/uikit.min.js"></script>

    </body>
</html>
