<?php 
    include("conexao.php");
    session_start();

    $email = $_POST['email'];
    $senha = $_POST['senha'];
    
    

    if((!empty($_POST)) && (!empty($_POST['email'])) && (!empty($_POST['senha']))){

      $sql =  $con->prepare("SELECT * FROM TB_FUNCIONARIO WHERE EMAIL ='$email' && SENHA = '$senha'");
      $sql->execute();
      $resultado = $sql->fetch();
        
         if(empty($resultado)){
            

              echo "usuario_invalido";
              die();
               }
        else{
			        $select_t = $con->prepare("SELECT ATIVO_DESATIVO from TB_FUNCIONARIO where EMAIL = :email");
              $select_t->bindValue("email",$email);
              $select_t->execute();
              $linha =  $select_t->fetch();
         if($resultado['FST_ACESSO'] == 1){
              if($linha["ATIVO_DESATIVO"] == 0){

        	      $TIPO = $resultado['TIPO'];
                $_SESSION['op'] = $TIPO;
                $_SESSION['sobrenome'] = $resultado['SOBRENOME'];
                $_SESSION['nome'] = $resultado['NOME'];
                $_SESSION['logado'] = true;
                $_SESSION['ID'] = $resultado['ID'];
               	echo "ativado";
                die();
               }else{
                $_SESSION['logado'] = true;
                echo "desativado";
                die();
               }
             }else{
              echo "primeiro_acesso";
             }
          }

    }
    
   die();

?>