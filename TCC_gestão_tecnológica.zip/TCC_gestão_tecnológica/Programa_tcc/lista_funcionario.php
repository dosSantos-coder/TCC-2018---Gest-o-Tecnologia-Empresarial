<!DOCTYPE html>
<html>
<head>
  <?php
  include("conexao.php");
      session_start();
      if(!isset($_SESSION['logado'] )){
        header("location:index.php");
     }
  ?>
  <style>
       #excluir:hover{
         background: red;
         color: #fff;
       }
       #hove:hover{
        background:#4d94ff;
        color: #fff;
       }
       #ativar:hover{
         background: blue;
         color: #fff;
       }
        footer {
        background-color: rgb(0, 55, 96);
        display: block;
        min-height: 140px;
        width: 100%;
    }
  </style>

  <title></title>
  <link href="css/uikit.min.css" rel="stylesheet">
</head>
  <body>
    <div class="uk-section-primary uk-preserve-color">

      <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

      <nav class="uk-navbar-container" uk-navbar>
              <div class="uk-navbar-left">

                  <ul class="uk-navbar-nav">
                      <li ><a href="Tela_adm.php">Home</a></li>
                      <li ><a href="cadastro_novo_funcionario.php">Novos Funcionário</a></li>
                     <li class="uk-active"><a href="lista_funcionario.php">Lista de Funcionários</a></li>
                  </ul>

              </div>
              <div class="uk-navbar-right">
                      <div class="uk-navbar-right">

           <ul class="uk-navbar-nav">
        
                      <li>
                          <a  href="#">Configurações</a>
                    <div class="uk-navbar-dropdown">
                        <ul class="uk-nav uk-navbar-dropdown-nav">
                            <li class="uk-active"><a href="#">configurações gerais</a></li>
                            <li><a href="troca_senha.php">Seu perfil</a></li>
                            <li class="uk-nav-divider"></li>
                            <li><a href="sair.php">Sair</a></li>
                        </ul>
                    </div>
                          </li>
                      </ul>
                  </div>
              </nav>
          </div>
      </div>
      <br>
      <?php 
           $select_user = $con->prepare("SELECT * FROM TB_FUNCIONARIO ");
           $select_user->execute();
           ?>
        <div class="uk-card uk-card-default">
           <div class="uk-card-header">
            <div class="uk-grid-small uk-flex-middle" uk-grid>
                <div class="uk-width-auto">
                  <h2>Usuarios cadastrados</h2>
                </div>
                <div class="uk-width-expand">
                    <h3 class="uk-card-title uk-margin-remove-bottom"><span class="uk-badge"><?php echo $select_user->rowCount(); ?></span></h3>
                </div>
            </div>
            <div style="float: right;">
              <?php 
                if(isset($_SESSION["vazio_alterar"])){
                      echo
                      '<div class="uk-alert-danger" style ="width:400px;" uk-alert>
                            <a class="uk-alert-close" uk-close></a>
                             <p> '.$_SESSION['vazio_alterar'].'</p>
                      </div>';
                        unset($_SESSION['vazio_alterar']);
                     }
                      if(isset($_SESSION["campo_nao_conferi"])){
                      echo
                      '<div class="uk-alert-danger" style ="width:400px;" uk-alert>
                            <a class="uk-alert-close" uk-close></a>
                             <p> '.$_SESSION['campo_nao_conferi'].'</p>
                      </div>';
                        unset($_SESSION['campo_nao_conferi']);
                     }
                      if(isset($_SESSION["sucesso_senha"])){
                      echo
                      '<div class="uk-alert-success" style ="width:400px;" uk-alert>
                            <a class="uk-alert-close" uk-close></a>
                             <p>✔ '.$_SESSION['sucesso_senha'].'</p>
                      </div>';
                        unset($_SESSION['sucesso_senha']);
                     }

                     if(isset($_SESSION["ativo_desativo"])){
                      echo
                      '<div class="uk-alert-success" style ="width:400px;" uk-alert>
                            <a class="uk-alert-close" uk-close></a>
                             <p>✔ '.$_SESSION['ativo_desativo'].'</p>
                      </div>';
                        unset($_SESSION['ativo_desativo']);
                     }
                     if(isset($_SESSION["sucesso_ex_fun"])){
                      echo
                      '<div class="uk-alert-success" style ="width:400px;" uk-alert>
                            <a class="uk-alert-close" uk-close></a>
                             <p>✔ '.$_SESSION['sucesso_ex_fun'].'</p>
                      </div>';
                        unset($_SESSION['sucesso_ex_fun']);
                     }


              ?>
            </div>
        </div>
          <div class="uk-card-body">
            <div>
              <table class="uk-table uk-table-responsive uk-table-divider">
                  <thead>
                      <tr>
                          <th>Nome do usuário</th>
                          <th>Senha</th>
                          <th>Departamento</th>
                          <th>Email</th>
                          <th>alterar senha</th>
                          <th>Status usuário</th>
                          <th>Excluir usuário</th>
                      </tr>
                  </thead>
                <?php
                   while($linha_user = $select_user->fetch()){
                   if($linha_user["ATIVO_DESATIVO"] == 0){
                 ?>
                  <tbody>
                      <tr>
                          <td><?php echo $linha_user["NOME"]." ".$linha_user["SOBRENOME"];?></td>
                          <td>**********</td>
                          <td><?php  if($linha_user["TIPO"] == 1)
                            {
                                echo "Funcionario";

                            }if($linha_user["TIPO"] == 0){

                                 echo "Tecnico em informatica"; 

                             }if($linha_user["TIPO"] == 2){
                               
                               echo "ADM";

                             }
                             ?>
                            
                          </td>
                          <td><?php echo $linha_user["EMAIL"]; ?></td>
                          <td>
                            <a class="uk-button uk-button-default" href="#modal-center<?php echo $linha_user["ID"];?>" id ="hove" uk-toggle>Alterar senha</a>
                            <div id="modal-center<?php echo $linha_user["ID"];?>" class="uk-flex-top" uk-modal>
                                <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">
                                   <div class="uk-modal-header">
                                        <h2 class="uk-modal-title">Alterar senha usuario</h2>
                                    </div><br>
                                  <button class="uk-modal-close-default" type="button" uk-close></button>
                                  <form action="alterar_senha_user.php" method="POST">
                                     <div class="uk-margin">
                                        <label>Nova senha</label><br>
                                        <input class="uk-input" type="password"  name= "Nsenha" >
                                    </div>
                                     <div class="uk-margin">
                                        <label>Confirmar senha</label><br>
                                        <input class="uk-input" type="password"  name="confirmarS"  >
                                    </div>
                                    <input type="hidden" name="id_fun" value="<?php  echo $linha_user["ID"]; ?>">
                                    <input type="submit" name="" class="uk-button uk-button-primary" value="alterar">
                                  </form>
                                </div>

                              </div>
                          </td>
                          <td>
                            <a class="uk-button uk-button-default" id="excluir" href="#modal-desativar<?php echo $linha_user['ID']; ?>" uk-toggle>Desativar</a>
                              <div id="modal-desativar<?php echo $linha_user['ID']; ?>" uk-modal>
                                <div class="uk-modal-dialog ">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header" style="background-color: red;">
                                        <h2 class="uk-modal-title" style="color: #fff;">Tem certeza que dejesa desativar esse usuario</h2>
                                    </div>
                                    <div class="uk-modal-body">
                                      <center>
                                        <h3>Nome: <?php echo $linha_user["NOME"]; ?></h3>
                                        <form action="desativar_user.php" method="POST">
                                        <input type="hidden"  name="id_user" id="<?php $linha_user['ID'];?>" value ="<?php echo $linha_user['ID'];?>">
                                        <button class="uk-button uk-button-Secondary uk-modal-close uk-button-large uk-width-1-3" type="button">Cancelar</button>
                                          <button class="uk-button uk-button-primary uk-button-large uk-width-1-3" type="submit">Desativar</button>
                                      </center>
                                    </div>
                                </form>
                            </div>
                            </div>
                          </td>
                          <td>
                             <a class="uk-button uk-button-default" id="excluir" href="#modal-ex<?php echo $linha_user['ID']; ?>" uk-toggle>Excluir</a>
                              <div id="modal-ex<?php echo $linha_user['ID']; ?>" uk-modal>
                                <div class="uk-modal-dialog ">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header" style="background-color: red;">
                                        <h2 class="uk-modal-title" style="color: #fff;">Tem certeza que dejesa excluir esse usuario</h2>
                                    </div>
                                    <div class="uk-modal-body">
                                      <center>
                                        <h3>Nome: <?php echo $linha_user["NOME"]; ?></h3>
                                        <form action="excluir_user.php" method="POST">
                                        <input type="hidden"  name="id_user" id="<?php $linha_user['ID'];?>" value ="<?php echo $linha_user['ID'];?>">
                                        <button class="uk-button uk-button-Secondary uk-modal-close uk-button-large uk-width-1-3" type="button">Cancelar</button>
                                          <button class="uk-button uk-button-primary uk-button-large uk-width-1-3" type="submit">excluir</button>
                                      </center>
                                    </div>
                                </form>
                            </div>
                            </div>
                          </td>
                        </tr>
                     
                  </tbody>
                 <?php 
                 }else{?>
          
               
                  <tbody>
                      <tr>
                          <td><?php echo $linha_user["NOME"]." ".$linha_user["SOBRENOME"];?></td>
                          <td>**********</td>
                          <td><?php  if($linha_user["TIPO"] == 1)
                            {
                                echo "Funcionario";

                            }if($linha_user["TIPO"] == 0){

                                 echo "Tecnico em informatica"; 

                             }if($linha_user["TIPO"] == 2){
                               
                               echo "ADM";

                             }
                             ?>
                            
                          </td>
                          <td><?php echo $linha_user["EMAIL"]; ?></td>
                          <td>
                            <button class="uk-button uk-button-default" href="#modal-center" disabled uk-toggle= >Alterar senha</button>
                            
                          </td>
                          <td>
                            <a class="uk-button uk-button-default" id="ativar" href="#modal-desativar<?php echo $linha_user['ID']; ?>" uk-toggle>Ativar </a>
                              <div id="modal-desativar<?php echo $linha_user['ID']; ?>" uk-modal>
                                <div class="uk-modal-dialog ">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header" style="background-color: red;">
                                        <h2 class="uk-modal-title" style="color: #fff;">Tem certeza que dejesa ativar esse usuario</h2>
                                    </div>
                                    <div class="uk-modal-body">
                                      <center>
                                        <h3>Nome: <?php echo $linha_user["NOME"]; ?></h3>
                                        <form action="ativar_user.php" method="POST">
                                        <input type="hidden"  name="id_user" id="<?php $linha_user['ID'];?>" value ="<?php echo $linha_user['ID'];?>">
                                        <button class="uk-button uk-button-Secondary uk-modal-close uk-button-large uk-width-1-3" type="button">Cancelar</button>
                                          <button class="uk-button uk-button-primary uk-button-large uk-width-1-3" type="submit">Ativar</button>
                                      </center>
                                    </div>
                                </form>
                            </div>
                            </div>
                          </td>
                          <td>
                             <a class="uk-button uk-button-default" id="excluir" href="#modal-ex<?php echo $linha_user['ID']; ?>" uk-toggle>Excluir</a>
                              <div id="modal-ex<?php echo $linha_user['ID']; ?>" uk-modal>
                                <div class="uk-modal-dialog ">
                                    <button class="uk-modal-close-default" type="button" uk-close></button>
                                    <div class="uk-modal-header" style="background-color: red;">
                                        <h2 class="uk-modal-title" style="color: #fff;">Tem certeza que dejesa excluir esse usuario</h2>
                                    </div>
                                    <div class="uk-modal-body">
                                      <center>
                                        <h3>Nome: <?php echo $linha_user["NOME"]; ?></h3>
                                        <form action="excluir_user.php" method="POST">
                                        <input type="hidden"  name="id_user" id="<?php $linha_user['ID'];?>" value ="<?php echo $linha_user['ID'];?>">
                                        <button class="uk-button uk-button-Secondary uk-modal-close uk-button-large uk-width-1-3" type="button">Cancelar</button>
                                          <button class="uk-button uk-button-primary uk-button-large uk-width-1-3" type="submit">excluir</button>
                                      </center>
                                    </div>
                                </form>
                            </div>
                            </div>
                          </td>
                     
                  </tbody>
             <?php }
           }?>
              </table>

        </div>
          </div>
      </div>
      <br><br><br>
   <footer>
    <br>
      <center><p style="color: white; display: inline;" >℗Copyright GerenciaEmpresa.com</p></center>
      <div style="color: white; float: right; margin-right: 200px; ">
        resdes socias <br><br>
        <img src="img/facebook.png" style="width: 30px; height: 30px; " uk-tooltip="title: GerenreciaMais">
        <img src="img/instagram.png" style="width: 30px; height: 30px;" uk-tooltip="title: @GerenciaSeuSistema">
        <img src="img/whatsapp.svg" style="width: 30px; height: 30px;" uk-tooltip="title: (11) 40028922">

      </div>
  </footer>
  </body>
        

        

        <script type="text/javascript" src="js/uikit.min.js"></script>
        <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
</html>
