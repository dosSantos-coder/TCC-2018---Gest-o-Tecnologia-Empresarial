<?php
  include("conexao.php");
  session_start();

try{
  
  echo $id_M_S = $_POST['id_maquina_software'];
  $query = "DELETE FROM MAQUINA_SOFTWARE WHERE ID = :ID";
  $sql = $con->prepare($query);
  $sql->bindValue(':ID',$id_M_S);
  $sql->execute();
  header("location: Gerencia_Computadores.php");

  $_SESSION['sucesso_add'] = "Software desvinculado";
}
catch(Exception $e){
        echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
     }
   
  die();




?>