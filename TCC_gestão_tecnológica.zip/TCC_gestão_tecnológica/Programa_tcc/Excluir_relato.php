<?php
	include("conexao.php");
	session_start();

try{
     echo $id = $_POST['id'];

     $query = $con->prepare("DELETE FROM TB_OS WHERE ID = '$id'");
    
     $query->execute();

     header("location: Tela_Home_funcionario.php");
     $_SESSION['sucesso_ex'] = "Excluido com sucesso";

 }
 catch(Exception $e){
		echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
	 }
?>