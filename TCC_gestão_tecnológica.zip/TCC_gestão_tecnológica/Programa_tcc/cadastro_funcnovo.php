<?php
   include("conexao.php");
   session_start();
try{
	   $nome_funcionario = $_POST['nome_funcionario'];
	   $nome_sobrenome = $_POST['nome_sobrenome'];
	   $op = $_POST['op'];
	   $idade = $_POST['idade'];
	   $senha = $_POST['senha'];
	   $email = $_POST['email'];

	   if(empty($op)){

          header("location:cadastro_novo_funcionario.php");
	   }
     else {
       if($op == "Técnico"){
          $op = '0';
       }
       if($op == "Funcionário"){

          $op = '1';
       }
     }
	   if(empty($nome_funcionario)){

	   	 header("location:cadastro_novo_funcionario.php");

	   }
	   if(empty($nome_sobrenome)){
	   	 header("location:cadastro_novo_funcionario.php");
	   }
	   if(empty($idade)){

	   	 header("location:cadastro_novo_funcionario.php");
	   }
	   if(empty($senha)){

	   	 header("location:cadastro_novo_funcionario.php");
	   }

     if(empty($email)){

	   	 header("location:cadastro_novo_funcionario.php");
	   }

echo $op;
	      $query = "INSERT INTO TB_FUNCIONARIO(EMAIL,SENHA,TIPO,NOME,SOBRENOME,IDADE,ATIVO_DESATIVO,FST_ACESSO)VALUES(?,?,?,?,?,?,0,0)";
	      $sql = $con->prepare($query);
	      $sql->bindValue(1,$email);
	      $sql->bindValue(2,$senha);
	      $sql->bindValue(3,$op);
	      $sql->bindValue(4,$nome_funcionario);
	      $sql->bindValue(5,$nome_sobrenome);
	      $sql->bindValue(6,$idade);
	      $sql->execute();

	      header("location:cadastro_novo_funcionario.php");

      }
      catch(Exception $e){
           echo 'Algum erro foi encontrado tente mais tarde:',  $e->getMessage();
   }
?>
