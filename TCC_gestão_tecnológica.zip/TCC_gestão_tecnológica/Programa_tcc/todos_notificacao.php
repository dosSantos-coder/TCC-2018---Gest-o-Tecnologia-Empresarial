
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="css/uikit.min.css" rel="stylesheet">
	<?php
	include("conexao.php");
     session_start();
    if(!isset($_SESSION['logado'] )){
      	header("location:index.php");
      }
	?>
	<style type="text/css">
		footer {
	  background-color: rgb(0, 55, 96);
	  display: block;
	  min-height: 100px;
	  width: 100%;
}
	</style>
</head>
<body>
		<div class="uk-card uk-card-primary uk-card-body">
            <h3 class="uk-card-title">Todas as Notifições</h3><button class="uk-button uk-button-default " onclick="goBack()" style="float:right; margin-top: 0px;">Voltar</button>
            <p >Apertando a Notifição ela vai te redirecionar a pagina de relatos.</p>
           
        </div><br><br>
        <center>
        	<div class="uk-child-width-1-2@m uk-grid-small uk-grid-match" uk-grid>
			    <div>
			        <div class="uk-card uk-card-default uk-card-body">
			         <?php $sql_noty = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0 ORDER BY ID DESC ");
		            	      $sql_noty->execute();
		            	      $tr = $sql_noty->rowCount();?>
			            <h3 class="uk-card-title"><a  href="#"><span style="margin: 3px; margin-top: -2px;" class="uk-badge"><?php echo $tr; ?></span>Notificações</a></h3>
			            <ul class="uk-nav ">
                      		    <?php if($tr > 0){ ?>
                      			<?php while ($linha_noty = $sql_noty->fetch()) {?>
                  				<li class="uk-nav-header">Relato</li>
		                        <li><a href="novos_relatos.php"><?php echo 'ID do relato: '.$linha_noty["ID_RELATO"]."</br> Nome relator: ".$linha_noty["NOME"]." ".$linha_noty["DATA_NOTIFICAO"]." ".$linha_noty["HORA_NOTIFICAO"]; ?></a>
		                        </li>
		                        <li><hr class="uk-divider-icon"></li>
		                    <?php }}?>
		                    </ul>
			        </div>
			    </div>
			</div>
		</center>
        
<script>
		function goBack() {
		    window.history.back()
		}
</script>
</body>
</html>
