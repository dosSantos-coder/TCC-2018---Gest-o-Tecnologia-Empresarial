<?php
	include("conexao.php");
     
  session_start();
try{
   echo $id_m = $_POST['id_m'];
       
   if($_POST['id_s'] != ''){
    
       foreach($_POST['id_s'] as $id_s){
        
        
         
           $query = "INSERT into MAQUINA_SOFTWARE(ID_MAQUINA,ID_SOFTWARE,STATUS_P)values(?,?,1)";
           $sql = $con->prepare($query);
           $sql->bindValue(1,$id_m);
           $sql->bindValue(2,$id_s);
           $sql->execute();
           

      }

      $_SESSION['sucesso_add'] = "Software adicionado";
    }
           
    else{
          echo "nao marcado";
        
    }

      header("location: Gerencia_Computadores.php");
    }
catch (Exception $e) {
  echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();

 }
	die();

?>

