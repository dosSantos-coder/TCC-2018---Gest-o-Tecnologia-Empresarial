<?php
  include("conexao.php");
  session_start();

  echo $departamento = $_POST['departamento'];
  echo $id = $_POST['id'];
  echo   $gravidade = $_POST['gravidade'];
  echo  $titulo = $_POST['titulo'];
  echo  $ramal = $_POST['ramal'];
  echo $Frequecia = $_POST['Frequecia'];
  echo $versao = $_POST['versao'];
  echo $desc = $_POST['desc'];

  date_default_timezone_set('America/Sao_Paulo');
  echo  $hora = date('H:i');
  echo  $data = date('d/m/Y');

   $query_relato = " UPDATE TB_OS SET TITULO = :titulo ,DEPARTAMENTO = :departamento ,GRAVIDADE = :gravidade,RAMAL = :ramal,FREQUECIA = :Frequecia,VERSAO=:versao,DESCRICAO = :DESCRICAO,DATA_ATUALIZACAO = :data,HORA_ATUALIZACAO = :hora WHERE ID = :id";
  $query = $con->prepare($query_relato);
     $query->bindValue(':titulo',$titulo);
     $query->bindValue(':departamento',$departamento);
     $query->bindValue(':gravidade',$gravidade);
     $query->bindValue(':ramal',$ramal);
     $query->bindValue(':Frequecia',$Frequecia);
     $query->bindValue(':versao',$versao);
     $query->bindValue(':DESCRICAO',$desc);
     $query->bindValue(':data',$data);
     $query->bindValue(':hora',$hora);
     $query->bindValue(':id',$id);
     $query->execute();

     $_SESSION['alterar_r'] = "Alterado com sucesso";
     header("location: tela_Home_funcionario.php");

   die();
?>