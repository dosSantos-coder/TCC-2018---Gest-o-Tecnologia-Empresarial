<?php
include("conexao.php");
session_start();

 $senha = $_POST['Nsenha'];
 $confirmar = $_POST['confirmarS'];
 $id = $_POST['id_fun'];

 if($senha == "" || $confirmar == ""){

 	echo $_SESSION['vazio_alterar'] = "algum campo está vazio";
    header("location:lista_funcionario.php");
 }
 else
 {
 	if($senha != $confirmar){

 		echo $_SESSION['campo_nao_conferi'] = "O campo nova senha e o  confirmar senha não sao compatíveis";
 	    header("location:lista_funcionario.php");

 	}
 	else
 	{
 		echo $_SESSION['sucesso_senha'] = "Senha alterada com sucesso";
 		$sql = $con->prepare("UPDATE TB_FUNCIONARIO SET SENHA = :senha WHERE ID = :id");
 		$sql->bindValue("senha",$senha);
 		$sql->bindValue("id",$id);
 		$sql->execute();
 	    header("location:lista_funcionario.php");



 	}
 }

 die();

?>