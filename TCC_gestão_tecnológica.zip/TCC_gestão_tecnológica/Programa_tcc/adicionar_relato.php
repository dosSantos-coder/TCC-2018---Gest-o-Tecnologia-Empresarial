<?php
  include("conexao.php");
  session_start();
try{
  echo  $id_erro = $_POST['id_relato'];
  echo $id = $_POST['id_pessoa'];
  echo $nome = $_POST['nome'];
  echo  $id_mando = $_POST['id_mando'];
  $query = "UPDATE TB_OS SET RELATO_PEGO = 1, relato_pego_Quem = :id_pessoa ,STATUS_ERRO = 0,nome_pego = :nome where ID = :id_erro";
  $sql = $con->prepare($query);
  $sql->bindValue(':id_pessoa',$id);
  $sql->bindValue(':nome',$nome);
  $sql->bindValue(':id_erro',$id_erro);
  
  $notificacao = "UPDATE NOTIFICACAO SET VIZUALIZAR = 1 WHERE ID_RELATO = :id_mando";
  $execute = $con->prepare($notificacao);
  $execute->bindValue("id_mando",$id_erro);
  
  $execute->execute();
  $sql->execute();
  header("Location:novos_relatos.php");

}
catch(Exception $e){
        echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
     }
   
  die();
?>
