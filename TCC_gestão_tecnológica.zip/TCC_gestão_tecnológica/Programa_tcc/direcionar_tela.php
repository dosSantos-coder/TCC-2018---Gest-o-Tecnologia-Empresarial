<?php
	 session_start();
	

	 switch ($_SESSION['op'] ){
	  	case '2':
	  		header('location: Tela_adm.php');
	  		break;
	  	case '1':
			 header('location: Tela_Home_funcionario.php');
	  		break;
	    case '0':
	  		 header('location: Gerencia_Computadores.php');
	  		break;
	  	default:
	  		 header('location: index.php');
	  		break;
	  } 
   die();

	 ?>


