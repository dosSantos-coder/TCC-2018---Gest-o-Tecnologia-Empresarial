<!DOCTYPE html>
<html>
<head>
	<?php
	include("conexao.php");
      session_start();
	 if(!isset($_SESSION['logado'] )){
      	header("location:index.php");
      }
	?>
	<title></title>
	<style type="text/css">
	* {
	  box-sizing: border-box;
	  padding: 0;
	  margin: 0;
	}

	main {
	  background-color: rgb(201, 225, 222);
	  display: block;
	  min-height: 100vh;
	  min-height: -webkit-calc(100vh - 100px);
	  min-height: -moz-calc(100vh - 100px);
	  min-height: calc(100vh - 100px);
	  position: relative;
	  width: 100%;
	}
	footer {
	  background-color: rgb(0, 55, 96);
	  display: block;
	  min-height: 100px;
	  width: 100%;
}
	</style>
	<link href="css/uikit.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="Table_Responsive/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="Table_Responsive/vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="Table_Responsive/vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="Table_Responsive/vendor/perfect-scrollbar/perfect-scrollbar.css">
	<link rel="stylesheet" type="text/css" href="css/table.css">
</head>
<body>

	<div class="uk-section-primary uk-preserve-color">

    <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

       <nav class="uk-navbar-container" uk-navbar>
		    <div class="uk-navbar-left">

		        <ul class="uk-navbar-nav">
		            <li ><a href="Gerencia_Computadores.php">Home</a></li>
		            <li><a href="Tela_Cadastrar_pc.php">Cadastros</a></li>
		            <li class="uk-active"><a href="todos_relatos.php">Tarefas</a></li>
		        </ul>

		    </div>
		    <div class="uk-navbar-right">

		        <ul class="uk-navbar-nav">
		            <li>
		                <a href="#">Notificações</a>
		                <div class="uk-navbar-dropdown">
		                    <ul class="uk-nav uk-navbar-dropdown-nav">
		                        <li class="uk-active"><a href="#">Active</a></li>
		                        <li><a href="#">Item</a></li>
		                        <li class="uk-nav-header">Header</li>
		                        <li><a href="#">Item</a></li>
		                        <li><a href="#">Item</a></li>
		                        <li class="uk-nav-divider"></li>
		                        <li><a href="#">Item</a></li>
		                    </ul>
		                </div>
		            </li>
		            <li>
		            	<a href="#">Configurações</a>
		                <div class="uk-navbar-dropdown">
		                    <ul class="uk-nav uk-navbar-dropdown-nav">
		                        <li class="uk-active"><a href="#">configuracoes gerais</a></li>
		                        <li><a href="#">conta</a></li>
		                        <li class="uk-nav-header">Perfil</li>
		                        <li><a href="#">configuracoes</a></li>
		                        <li><a href="troca_senha.php">troca de senha</a></li>
		                        <li class="uk-nav-divider"></li>
		                        <li><a href="sair.php">Sair</a></li>
		                    </ul>
		                </div>
		            </li>
		        </ul>
		    </div>
		</nav>
    </div>
    <div class="uk-section">
    	<div class="uk-container">
    		<center><h1 style="color: #fff;">Tarefas</h1></center>
    	</div>
    </div>
</div>
<nav class="uk-navbar-container uk-background-secondary  uk-panel uk-card uk-card-default uk-card-body" style="z-index: 900; height: 80px;" uk-sticky="offset: 80; bottom: #top" uk-navbar>
    <div class="uk-navbar-center">
    	<div class="uk-navbar-center-left"><div>
            <ul class="uk-navbar-nav">
                <li ><a href="novos_relatos.php">Novos Casos</a></li>
                
            </ul>
        </div>
    </div>
     <div class="uk-navbar"><div>
            <ul class="uk-navbar-nav">
                <li><a href="meus_relatos.php">Meus casos</a></li>
            </ul>
        </div>
    </div>
        <div class="uk-navbar-center-right">
        <div>
        <div>
            <ul class="uk-navbar-nav">
                <li><a href="casos_resolvidos.php">casos resolvidos</a></li>
            </ul>
        </div>
            <ul class="uk-navbar-nav">
                <li class="uk-active"><a href="#" >Todos os casos</a></li>
            </ul>
        </div>
    </div>
   </div>
    <div class="uk-navbar-left">

        <div>
        	<a class="uk-navbar-toggle" uk-search-icon href="#"></a>
            <div class="uk-drop" uk-drop="mode: click; pos: left-center; offset: 0">
        	<form class="uk-search uk-search-navbar uk-width-1-1" action="buscar_todos_relatos.php"   method="POST" id="busca_todos">
                    <input class="uk-search-input" type="text" placeholder="Buscar caso..." name="buscar_caso" id ="text_b" autofocus >
                </form>
                

            </div>
        </div>

    </div>
 </nav>
 <?php   
   $busca = $_POST['buscar_caso'];
   $sql = $con->prepare("SELECT * FROM  tb_os where NOME_MANDO LIKE '%".$busca."%' limit 20");
   $sql->execute(); ?>
   <div id="busca">
 	<div>
        <div class="uk-card uk-card-hover uk-card-body">
        <?php  if($sql->rowCount() > 0 ){ ?>
            <h3 class="uk-card-title">Busca realizada</h3><button  type="button" uk-tooltip="title:Fechar busca; pos: right" uk-close  onclick="fechar()" style="float: right;"></button>
                  <table class="uk-table" style="width: 400px; height: 100px;">
                     

				    <thead>
				            <tr class="table100-head">
								<th class="column1">Data e Hora</th>
								<th class="column2">ID</th>
								<th class="column3">Nome</th>
								<th class="column4">Departamento</th>
								<th class="column5">Gravidade</th>
								<th class="column6">Frequecia</th>
								<th class="column7">Ramal</th>
								<th class="column8">Data atulizada</th>
								<th class="column9">Hora atualizada</th>
								<th class="column10">Status</th>
				        </tr>
				    </thead>
       
     
    
  <?php  while ($linha_busca =  $sql->fetch()){?>

			    <tbody>
			            <?php if($linha_busca['STATUS_ERRO'] == 0){ ?>
								<tr>
									<td class="column1"><?php echo $linha_busca['DATA_ENVIO'];?> <?php echo $linha_busca['HORA_ENVIO'] ?></td>
									<td class="column2"><?php echo $linha_busca['ID'];?></td>
									<td class="column3"><?php echo $linha_busca['NOME_MANDO']; ?></td>
									<td class="column4"><?php echo $linha_busca['DEPARTAMENTO'] ?></td>
									<td class="column5"><?php echo $linha_busca['GRAVIDADE'] ?></td>
									<td class="column6"><?php echo $linha_busca['FREQUECIA'];?></td>
									<td class="column7"><?php echo $linha_busca['RAMAL'];?></td>
									<td class="column8"><?php echo $linha_busca['DATA_ATUALIZACAO'];?></td>
									<td class="column9"><?php echo $linha_busca['HORA_ENVIO'] ?></td>
									<td class="column10"><div uk-tooltip="title: Em execução; pos: right" style=" border-radius: 100%; border:10px solid yellow ;  border-width: 10px; width: 10px;"></div></td>
								</tr>
								<?php }?>
								<?php if($linha_busca['STATUS_ERRO'] == 1){ ?>
								<tr>
									<td class="column1"><?php echo $linha_busca['DATA_ENVIO'];?> <?php echo $linha_busca['HORA_ENVIO'] ?></td>
									<td class="column2"><?php echo $linha_busca['ID'];?></td>
									<td class="column3"><?php echo $linha_busca['NOME_MANDO']; ?></td>
									<td class="column4"><?php echo $linha_busca['DEPARTAMENTO'] ?></td>
									<td class="column5"><?php echo $linha_busca['GRAVIDADE'] ?></td>
									<td class="column6"><?php echo $linha_busca['FREQUECIA'];?></td>
									<td class="column7"><?php echo $linha_busca['RAMAL'];?></td>
									<td class="column8"><?php echo $linha_busca['DATA_ATUALIZACAO'];?></td>
									<td class="column9"><?php echo $linha_busca['HORA_ENVIO'] ?></td>
									<td class="column10"><div uk-tooltip="title: Concluido; pos: right"  style=" border-radius: 100%; border:10px solid green;  border-width: 10px; width: 10px;"></div></td>
								</tr>
								<?php }?>
								<?php if($linha_busca['STATUS_ERRO'] == 2){ ?>
								<tr>
									<td class="column1"><?php echo $linha_busca['DATA_ENVIO'];?> <?php echo $linha_busca['HORA_ENVIO'] ?></td>
									<td class="column2"><?php echo $linha_busca['ID'];?></td>
									<td class="column3"><?php echo $linha_busca['NOME_MANDO']; ?></td>
									<td class="column4"><?php echo $linha_busca['DEPARTAMENTO'] ?></td>
									<td class="column5"><?php echo $linha_busca['GRAVIDADE'] ?></td>
									<td class="column6"><?php echo $linha_busca['FREQUECIA'];?></td>
									<td class="column7"><?php echo $linha_busca['RAMAL'];?></td>
									<td class="column8"><?php echo $linha_busca['DATA_ATUALIZACAO'];?></td>
									<td class="column9"><?php echo $linha_busca['HORA_ENVIO'] ?></td>
									<td class="column10"><div uk-tooltip="title: Novo relato; pos: right"  style=" border-radius: 100%; border:10px solid red ;  border-width: 10px; width: 10px;"></div></td>
								</tr>
								<?php }?>
			        
			    </tbody>
			<?php }
		}else{
			echo "<center><h1>Não a cadastros com esse nome</h1></center><br><br><br>";
		}
		?>
  </table>
   </div>
  </div>
 </div>
 <div id ="todos_rela">
    <div class="uk-background-default uk-padding" >
        	<div class="uk-overflow-auto">
        		<table class="uk-table  uk-table-divider">
						<thead>
							<tr class="table100-head">
								<th class="column1">Data e Hora</th>
								<th class="column2">ID</th>
								<th class="column3">Nome</th>
								<th class="column4">Departamento</th>
								<th class="column5">Gravidade</th>
								<th class="column6">Frequecia</th>
								<th class="column7">Ramal</th>
								<th class="column8">Data atulizada</th>
								<th class="column9">Hora atualizada</th>
								<th class="column10">Status</th>
							</tr>
						</thead>
						 <?php 
				     $id_pessoa = $_SESSION['ID'];
							 //recebe o numero da pagina
				     
			          $pagina_atual =  filter_input(INPUT_GET,'pagina_todos_relatos',
			          FILTER_SANITIZE_NUMBER_INT);
			          $pagina = (!empty($pagina_atual)) ? $pagina_atual : 1;
			          $quanti_result_pg = 7;
			          $inicio = ($quanti_result_pg * $pagina) - $quanti_result_pg;
				      $sql_erro = $con->prepare("SELECT * FROM TB_OS    LIMIT $inicio,$quanti_result_pg ");
				      $sql_erro->execute(); ?>
				       <?php while ($linha_erro = $sql_erro->fetch()) { ?>
						<tbody>
								<?php if($linha_erro['STATUS_ERRO'] == 0){ ?>
								<tr>
									<td class="column1"><?php echo $linha_erro['DATA_ENVIO'];?> <?php echo $linha_erro['HORA_ENVIO'] ?></td>
									<td class="column2"><?php echo $linha_erro['ID'];?></td>
									<td class="column3"><?php echo $linha_erro['NOME_MANDO']; ?></td>
									<td class="column4"><?php echo $linha_erro['DEPARTAMENTO'] ?></td>
									<td class="column5"><?php echo $linha_erro['GRAVIDADE'] ?></td>
									<td class="column6"><?php echo $linha_erro['FREQUECIA'];?></td>
									<td class="column7"><?php echo $linha_erro['RAMAL'];?></td>
									<td class="column8"><?php echo $linha_erro['DATA_ATUALIZACAO'];?></td>
									<td class="column9"><?php echo $linha_erro['HORA_ENVIO'] ?></td>
									<td class="column10"><div uk-tooltip="title: Em execução; pos: right" style=" border-radius: 100%; border:10px solid yellow ;  border-width: 10px; width: 10px;"></div></td>
								</tr>
								<?php }?>
								<?php if($linha_erro['STATUS_ERRO'] == 1){ ?>
								<tr>
									<td class="column1"><?php echo $linha_erro['DATA_ENVIO'];?> <?php echo $linha_erro['HORA_ENVIO'] ?></td>
									<td class="column2"><?php echo $linha_erro['ID'];?></td>
									<td class="column3"><?php echo $linha_erro['NOME_MANDO']; ?></td>
									<td class="column4"><?php echo $linha_erro['DEPARTAMENTO'] ?></td>
									<td class="column5"><?php echo $linha_erro['GRAVIDADE'] ?></td>
									<td class="column6"><?php echo $linha_erro['FREQUECIA'];?></td>
									<td class="column7"><?php echo $linha_erro['RAMAL'];?></td>
									<td class="column8"><?php echo $linha_erro['DATA_ATUALIZACAO'];?></td>
									<td class="column9"><?php echo $linha_erro['HORA_ENVIO'] ?></td>
									<td class="column10"><div uk-tooltip="title: Concluido; pos: right"  style=" border-radius: 100%; border:10px solid green;  border-width: 10px; width: 10px;"></div></td>
								</tr>
								<?php }?>
								<?php if($linha_erro['STATUS_ERRO'] == 2){ ?>
								<tr>
									<td class="column1"><?php echo $linha_erro['DATA_ENVIO'];?> <?php echo $linha_erro['HORA_ENVIO'] ?></td>
									<td class="column2"><?php echo $linha_erro['ID'];?></td>
									<td class="column3"><?php echo $linha_erro['NOME_MANDO']; ?></td>
									<td class="column4"><?php echo $linha_erro['DEPARTAMENTO'] ?></td>
									<td class="column5"><?php echo $linha_erro['GRAVIDADE'] ?></td>
									<td class="column6"><?php echo $linha_erro['FREQUECIA'];?></td>
									<td class="column7"><?php echo $linha_erro['RAMAL'];?></td>
									<td class="column8"><?php echo $linha_erro['DATA_ATUALIZACAO'];?></td>
									<td class="column9"><?php echo $linha_erro['HORA_ENVIO'] ?></td>
									<td class="column10"><div uk-tooltip="title: Novo relato; pos: right"  style=" border-radius: 100%; border:10px solid red ;  border-width: 10px; width: 10px;"></div></td>
								</tr>
								<?php }?>
							
								
						</tbody>
						  <?php }?>
					</table>
				</div>
			</div>
		
<?php $r_pg = $con->prepare("SELECT COUNT(ID) AS NUM_ROWS FROM TB_OS");
             $r_pg->execute();
             $row_erro = $r_pg->fetch();
             $q_pg_erro = ceil($row_erro['NUM_ROWS'] / $quanti_result_pg );
             $max_links = 2;  ?>
             <ul class="uk-pagination uk-flex-center" uk-margin>
			    <li><a class="page-link" href="todos_relatos.php?pagina_todos_relatos=1"><span uk-pagination-previous></span></a></li><?php for($pagina_ant = $pagina - $max_links; $pagina_ant <= $pagina - 1; $pagina_ant++){
                  if($pagina_ant >=1){
                  ?></li>
			    <li><a class="page-link" href="todos_relatos.php?pagina_todos_relatos=<?php echo $pagina_ant;?>"><?php echo $pagina_ant;?></a></li>
			    <li>
			    <?php }}?>
			    <li><a class="page-link" href="todos_relatos.php?pagina_todos_relatos=<?php echo $pagina;?>"><?php echo $pagina;?></a></li>
			     <?php for($pg_dps = $pagina + 1; $pg_dps <= $pagina + $max_links; $pg_dps++){
                  if($pg_dps <= $q_pg_erro){
                  ?>
			    <li> <a class="page-link" href="todos_relatos.php?pagina_todos_relatos=<?php echo $pg_dps;?>"><?php echo $pg_dps;?></a></li>
			    <?php }}?>
			    <li> <a class="page-link" href="todos_relatos.php?pagina_todos_relatos=<?php echo $q_pg_erro;?>"><span uk-pagination-next></span></a></li>
			</ul>
			<br>
	</div>
  <footer></footer>
  <script type="text/javascript" src="js/uikit.min.js"></script>
  <script type="text/javascript" src="js_personalizado/validar_cadastro_ti.js"></script>
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
</body>
</html>

