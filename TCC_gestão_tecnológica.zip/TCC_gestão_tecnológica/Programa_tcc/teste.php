<?php
   include("conexao.php");
      $id_maquina = 20;
      $query_add_S = $con->prepare ("SELECT s.id,m.NOME_PC,soft.NOME_VERSAO,soft.ATIV_DESAT FROM TB_CONTROLE_M m inner join MAQUINA_SOFTWARE s
      on m.ID = s.ID_MAQUINA inner join TB_SOFTWARE soft  on soft.id = s.ID_SOFTWARE  where m.ID = '$id_maquina' ");

      $query_add_S->execute();

      $row_add_soft = $query_add_S->rowCount();

      if($row_add_soft == 0 ){
      	echo ' <center>Sem software vinculados</center>','<br><br>';
      }
      while ($linha_soft = $query_add_S->fetch()) {?>
      
      <form action="desvincular.php" method="POST">
      	<!-- desvinculando o software -->
      	<center>
      	 <input type="hidden" name="id_maquina_software" value="<?php echo $linha_soft['id'];?>">
      	 <p><?php echo $linha_soft['NOME_VERSAO'];?></p><button  class="uk-button uk-button-primary">desvincular</button>
      	</center>
       
       </form>
              
     <?php  }
      ?> <!-- termino de mostrar o software -->

 <?php

		      $query_Sofware = $con->prepare("SELECT * FROM TB_SOFTWARE ");
		      $query_Sofware->execute();
	          $num =  $query_Sofware->rowCount();

	      if($num > 0){
	      	while ($linha = $query_Sofware->fetch()){ 
	      	  ?>
             
			 <form action ="add_soft.php" method="POST">
			 	<input type="hidden"  name="id_m" id="<?php $resultado['ID'];?>" value ="<?php echo $resultado['ID'];?>">
	            <div class="uk-margin uk-grid-small uk-child-width-auto uk-grid">
	            	<label><input class="uk-checkbox" type ="checkbox" class="check" name="id_s[]" id ="<?php echo $linha['ID'];?>" value="<?php echo $linha['ID']; ?>"> <h4 style="display: inline;"><?php echo $linha['NOME_VERSAO'];?></h4></label>
	            </div>
	        <?php
	            }
			 }

			  else{
			     	echo "<center>Sem cadartros</center>";
			   } ?>
	</div>