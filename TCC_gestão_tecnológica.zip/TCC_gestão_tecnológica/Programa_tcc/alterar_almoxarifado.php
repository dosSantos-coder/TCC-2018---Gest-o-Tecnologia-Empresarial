<?php
   include("conexao.php");
   session_start();
try{
    $produto = $_POST['produto'];
    $quantidade = $_POST['quantidade'];
    $fornecedor = $_POST['fonecedor'];
    $prateleira = $_POST['prateleira'];
    $notas = $_POST['nota'];
    $u_n = $_POST['usado_novo'];
    $id = $_POST['id_almoxa'];

    $sql = "UPDATE TB_AUMOXA
    SET PRODUTO = :produto , QUANTIDADE = :quantidade, USADO_NOVO =:usado_novo,FORNCEDOR =:fonecedor,PRATELEIRA=:prateleira,NOTAS=:notas
    WHERE ID = :id";
    $alterar = $con->prepare($sql);
    $alterar->bindValue(':produto',$produto);
    $alterar->bindValue(':quantidade',$quantidade);
    $alterar->bindValue(':usado_novo',$u_n);
    $alterar->bindValue(':fonecedor',$fornecedor);
    $alterar->bindValue(':prateleira',$prateleira);
    $alterar->bindValue(':notas',$notas);
    $alterar->bindValue(':id',$id);

    $alterar->execute();
    header("location: Gerencia_Almoxarifado.php");

    $_SESSION['sucesso'] = "alterado com sucesso";

}catch(Exception $e){
        echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
     }
   die();

 ?>