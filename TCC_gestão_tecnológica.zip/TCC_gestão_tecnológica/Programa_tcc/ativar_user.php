<?php 
 include("conexao.php");
 session_start();
try{
 $id = $_POST['id_user'];
 
 $sql = $con->prepare("UPDATE TB_FUNCIONARIO SET ATIVO_DESATIVO = 0 WHERE ID = :id");
 $sql->bindValue("id",$id);
 $sql->execute();
 
 $_SESSION['ativo_desativo'] = "Usuario ativado com sucesso";
 
 header("location:lista_funcionario.php");
}
catch(Exception $e){
     echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
	  }


 die();


?>