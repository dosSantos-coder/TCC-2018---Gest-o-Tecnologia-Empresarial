<?php
	include("conexao.php");
	session_start();

try{
     echo $id = $_POST['id'];

     $query = $con->prepare("DELETE FROM TB_SOFTWARE WHERE ID = '$id'");
    
     $query->execute();

     header("location: Gerencia_Software.php");
     $_SESSION['sucesso_ex'] = "Excluido com sucesso";

 }
 catch(Exception $e){
		echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
	 }
?>