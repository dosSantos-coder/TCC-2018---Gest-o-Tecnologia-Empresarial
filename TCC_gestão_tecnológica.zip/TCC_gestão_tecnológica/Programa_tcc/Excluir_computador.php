<?php
	include("conexao.php");
 session_start();
try{
     $id = $_POST['id'];


     $sql = $con->prepare("DELETE FROM TB_CONTROLE_M
            WHERE ID = '$id'");

     $sql->execute();

		 $_SESSION['sucesso_ex'] = "Excluido com sucesso";

     header("location: Gerencia_Computadores.php");
	 }
	 catch(Exception $e){
				echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
	 }
       die();
?>
