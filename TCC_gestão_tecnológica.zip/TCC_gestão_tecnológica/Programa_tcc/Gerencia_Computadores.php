<!DOCTYPE html>
<html>
<head>
	<?php
	include("conexao.php");
      session_start();
      if(!isset($_SESSION['logado'] )){
      	header("location:index.php");
     }

	?>
	<style>
		   #excluir:hover{
				 background: red;
				 color: #fff;
			 }
		   #hove:hover{
		   	background:#4d94ff;
		   	color: #fff;
		   }
	       * {
			  box-sizing: border-box;
			  padding: 0;
			  margin: 0;
			}

		   footer {
			  background-color: rgb(0, 55, 96);
			  display: block;
			  min-height: 140px;
			  width: 100%;
		}
			</style>

	<title></title>
	<link href="css/uikit.min.css" rel="stylesheet">
</head>
<body>
	<div class="uk-section-primary uk-preserve-color">

    <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

       <nav class="uk-navbar-container" uk-navbar>
		    <div class="uk-navbar-left">

		        <ul class="uk-navbar-nav">
		            <li class="uk-active"><a href="#">Home</a></li>
		            <li><a href="Tela_Cadastrar_pc.php">Cadastros</a></li>
		            <li><a href="novos_relatos.php">Tarefas</a></li>
		            
		        </ul>

		    </div>
		     <div class="uk-navbar-center">
		     <br>
		     		<h4>Olá <?php echo $_SESSION["nome"]." ".$_SESSION['sobrenome'];?></h4>
		     	
		     </div>
		    <div class="uk-navbar-right">

		        <ul class="uk-navbar-nav">
		            <li>
		            	<?php $not = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0");
		            	      $not->execute();
		            	      $tr = $not->rowCount();
		            	      $sql_noty = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0 ORDER BY ID DESC limit 3 "); 
                              $sql_noty->execute();?>
                              <a  href="#"><span style="margin: 7px;" class="uk-badge"><?php echo $tr; ?></span>Notificações</a>
                              <div class="uk-navbar-dropdown" style="overflow: auto;">
                              	<ul class="uk-nav uk-navbar-dropdown-nav">
                              		<?php if($tr > 0){ ?>
                              			<?php while ($linha_noty = $sql_noty->fetch()) {?>
                              				<li class="uk-nav-header">Relato</li>
					                        <li><a href="novos_relatos.php"><?php echo 'ID do relato: '.$linha_noty["ID_RELATO"]."</br> Nome relator: ".$linha_noty["NOME"]." ".$linha_noty["DATA_NOTIFICAO"]." ".$linha_noty["HORA_NOTIFICAO"]; ?></a>
					                        </li>
					                    <?php }
				                    echo "<li class='uk-nav-divider'></li>
				                          <li><a href='todos_notificacao.php'>Mostrar todos Relato</a></li>";
				                }else{
				                	echo "Sem notificação novas";
				                }?>

				                    </ul>
				                </div>
				            </li>
		            <li>
		            	<a  href="#">Configurações</a>
		                <div class="uk-navbar-dropdown">
		                    <ul class="uk-nav uk-navbar-dropdown-nav">
		                        <li class="uk-active"><a href="#">configurações gerais</a></li>
		                        <li><a href="troca_senha.php">Seu perfil</a></li>
		                        <li class="uk-nav-divider"></li>
		                        <li><a href="sair.php">Sair</a></li>
		                    </ul>
		                </div>
		            </li>
		        </ul>
		    </div>
		</nav>
    </div>
    <div class="uk-section">
    	<div class="uk-container">
    		<center><h1 style="color: #fff;">Gerenciamento</h1></center>
    	</div>
    </div>
</div>
<nav class=" uk-navbar-container uk-background-secondary  uk-panel" style="z-index: 900; height: 80px;" uk-sticky="offset: 80; bottom: #top" uk-navbar>
    <div class="uk-navbar-center">
    	<div class="uk-navbar-center-left"><div>
            <ul class="uk-navbar-nav">
                <li class="uk-active"><a href="#">Computadores</a></li>

            </ul>
        </div>
    </div>
     <div class="uk-navbar"><div>
            <ul class="uk-navbar-nav">
                <li><a href="Gerencia_Software.php">Software</a></li>
            </ul>
        </div>
    </div>
        <div class="uk-navbar-center-right"><div>
            <ul class="uk-navbar-nav">
                <li><a href="Gerencia_Almoxarifado.php">Almoxarifado</a></li>
            </ul>
        </div>
    </div>
</div>
</nav>
    <div>
    	<!-- computadores -->
        <div class="uk-background-default uk-padding">
        	<div class="uk-overflow-auto">
        		<table class="uk-table  uk-table-divider">
        			<div>
        				<h3 style="display: inline;">computadores</h3>
        				<span class="uk-badge" style="margin-top: -6px;">
        					<?php
        					$quentidade_m = $con->prepare("SELECT * FROM TB_CONTROLE_M");
        					$quentidade_m->execute();
        					echo $quentidade_m->rowCount();
        					?>
        					</span>
        					<div class="uk-align-right">
        						<!-- mostra notificacao de alteracao -->

        						<?php 
        						if(isset($_SESSION["sucesso_add"])){
        							echo
        							'<div class="uk-alert-success" style ="width:400px;" uk-alert>
        							      <a class="uk-alert-close" uk-close></a>
        							       <p>✔ '.$_SESSION['sucesso_add'].'</p>
        							</div>';
        						   	unset($_SESSION['sucesso_add']);
        						 }

        						if(isset($_SESSION["sucesso"])){
        							echo
        							'<div class="uk-alert-success" style ="width:400px;" uk-alert>
        							      <a class="uk-alert-close" uk-close></a>
        							       <p>✔ '.$_SESSION['sucesso'].'</p>
        							</div>';
        						   	unset($_SESSION['sucesso']);
        						 }
							   if(isset($_SESSION['sucesso_ex'])){
									 echo
									 '<div class="uk-alert-success" style ="width:400px;" uk-alert>
									 			<a class="uk-alert-close" uk-close></a>
									 			 <p>✔ '.$_SESSION['sucesso_ex'].'</p>
									 </div>';
									 	unset($_SESSION['sucesso_ex']);
									 }
							 ?>
        					</div>
		        		</div>
				    <thead>
				        <tr>
				            <th class="uk-width-small">Nome do Pc</th>
				            <th>Departamento</th>
				            <th>Informacoes</th>
				            <th>ADD Software</th>
				            <th>Alterar</th>
				            <th>Excluir</th>
				        </tr>
				    </thead>
				    <?php
				     $query_m = $con->prepare("SELECT * FROM TB_CONTROLE_M");
			         $query_m->execute();
			         
			          while($resultado = $query_m->fetch()) {

         			?>
				    <tbody>
				        <tr>
				            <td><?php echo $resultado['NOME_PC'];?></td>
				            <td><?php echo $resultado['DEPARTAMENTO']?></td>
				            <td>
				            	<a class="uk-button uk-button-default" href="#modal-informacoes_pc<?php echo $resultado['ID']; ?>" id="hove" uk-toggle>informacoes</a>
									<div id="modal-informacoes_pc<?php echo $resultado['ID']; ?>" class="uk-modal-full" uk-modal>
									    <div class="uk-modal-dialog">
									        <button class="uk-modal-close-full uk-close-large" type="button" uk-close></button>
									        <div class="uk-grid-collapse uk-child-width-1-2@s uk-flex-middle" uk-grid>
									            <!-- <div class="uk-background-cover" style="background-image: url(<?php echo "img/".$resultado['imagem_pc']; ?>);" uk-height-viewport></div> -->
									            <img class="uk-background-cover" src="
									            	<?php 
										            	if($resultado['imagem_pc'] != ""){ 
										            		echo "img/".$resultado['imagem_pc'];
										            	 }
										            	else{
										            		echo "imagens/4analistas-dizem-que-pcs-terao-ciclo-de-vida-estendido.jpg";
										            	}
										            ?>
										            " style = " height: 200px; width: 600px;" uk-height-viewport>
									            <div class="uk-padding-large">
									                <h1>Informações</h1>
									                <p>Nome do computador: <?php echo $resultado['NOME_PC'];?></p>
									                <p>Departamento: <?php echo $resultado['DEPARTAMENTO'];?></p>
									                <p>IP: <?php echo $resultado['IP'];?></p>
									                <p>HD: <?php echo $resultado['HD'];?></p>
									                <p>Memoria Ram: <?php echo $resultado['MEMORIA'];?></p>
									                <p>Processador: <?php echo $resultado['PROCESSADOR'];?></p>
									            </div>
									        </div>
									    </div>
									</div>
				            </td>
				            <td><a class="uk-button uk-button-default" href="#modal-mostrar_s<?php echo $resultado['ID']; ?>" id ="hove" uk-toggle>Programas</a></td>
				            <div id="modal-mostrar_s<?php echo $resultado['ID']; ?>" uk-modal>
							    <div class="uk-modal-dialog" >
							        <button class="uk-modal-close-default" type="button" uk-close></button>
							        <div class="uk-modal-header">
							            <h2 class="uk-modal-title">Listas de programas</h2>
							        </div>
							        <div class="uk-modal-body" uk-overflow-auto>
							        	<!-- começo de mostrar software -->
							        	<?php
			                                  $id_maquina = $resultado['ID'];
			                                  $query_add_S = $con->prepare ("SELECT s.id,m.NOME_PC,soft.NOME_VERSAO,soft.ATIV_DESAT FROM TB_CONTROLE_M m inner join MAQUINA_SOFTWARE s
			                                  on m.ID = s.ID_MAQUINA inner join TB_SOFTWARE soft  on soft.id = s.ID_SOFTWARE  where m.ID = '$id_maquina' ");

			                                  $query_add_S->execute();

			                                  $row_add_soft = $query_add_S->rowCount();

			                                  if($row_add_soft == 0 ){
			                                  	echo ' <center>Sem software vinculados</center>','<br><br>';
			                                  }
			                                  while ($linha_soft = $query_add_S->fetch()) {?>
			                                  
			                                  <form action="desvincular.php" method="POST">
			                                  	<!-- desvinculando o software -->
			                                 <div style="overflow: auto;">
			                                  	<center>
			                                  	 <input type="hidden" name="id_maquina_software" value="<?php echo $linha_soft['id'];?>">
			                                  	 <p><?php echo $linha_soft['NOME_VERSAO'];?></p><button  class="uk-button uk-button-primary">desvincular</button>
			                                  	</center>
			                                  </div>
									           
									           </form>

			                                 <?php }
			                                  ?> <!-- termino de mostrar o software -->
			                              </div>
			                              <div class="uk-modal-footer uk-text-right">

			                              	<button class="uk-button uk-button-default uk-modal-close" type="button">Sair</button>
			                              	<a href="#modal-add<?php echo $resultado['ID'];?>" class="uk-button uk-button-primary" uk-toggle>Adicionar programa</a>
			                              </div>
			                          </div>
			                      </div>
							<!-- segundo modal  -->
							<div id="modal-add<?php echo $resultado['ID'];?>" uk-modal>
							    <div class="uk-modal-dialog">
							        <button class="uk-modal-close-default" type="button" uk-close></button>
							        <div class="uk-modal-header">
							            <h2 class="uk-modal-title">Adicionar software</h2>
							        </div>
							        <div class="uk-modal-body" uk-overflow-auto>
							        <?php
                                        
							      	      $query_Sofware = $con->prepare("SELECT * FROM TB_SOFTWARE ");
							      	      $query_Sofware->execute();
                                          $num =  $query_Sofware->rowCount();

                                          if($num > 0){
                                          	while ($linha = $query_Sofware->fetch()){?>

                                          	<form action ="add_soft.php" method="POST">
											 	<input type="hidden"  name="id_m" id="<?php $resultado['ID'];?>" value ="<?php echo $resultado['ID'];?>">
	                                            <div class="uk-margin uk-grid-small uk-child-width-auto uk-grid">
	                                            	<label>
	                                            		<input class="uk-checkbox" type ="checkbox" class="check" name="id_s[]" id ="<?php echo $linha['ID'];?>" value="<?php echo $linha['ID']; ?>"
	                                            		<?php 
			                                               $id_m = $resultado["ID"];
			                                               $id_s = $linha["ID"];
			                                               $query_t = $con->prepare("SELECT STATUS_P FROM MAQUINA_SOFTWARE where ID_MAQUINA = :idM and ID_SOFTWARE = :idS");
			                                               $query_t->bindValue("idM",$id_m);

			                                               $query_t->bindValue("idS",$id_s);

				                                           $query_t->execute();

		                                                   while ($result_test = $query_t->fetch()) {
		                                                        if($result_test['STATUS_P'] == 1){
		                                                        	echo "checked"." disabled";
		                                                        }
		                                                    }
		                                                    // teste se o computador tem software. Se tiver ele vai vim checado 
		                                                    ?>> 
	                                            		<h4 style="display: inline;"><?php echo $linha['NOME_VERSAO'];?></h4>
	                                            	</label>
	                                            </div>
                                            <?php
                                                }
											 }

											  else{
											     	echo "<center>Sem cadartros</center>";
											   } ?>
								    </div>
							        <div class="uk-modal-footer uk-text-right">
							        	<a href="#modal-mostrar_s<?php echo $resultado['ID']; ?>" class="uk-button uk-button-primary" uk-toggle>Voltar</a>
							             <input type="submit" name="" class="uk-button uk-button-default" value="cadastrar">
							          </form>
							        </div>
							    </div>
							</div>
							<!-- fim do 2 modal -->

				            <!-- modal de alteracao -->
				            <td><a class="uk-button uk-button-default" href="#modal-alterar<?php echo $resultado['ID']; ?>" id="hove" uk-toggle>Alterar</a>
				            	<div id="modal-alterar<?php echo $resultado['ID']; ?>" uk-modal>
								    <div class="uk-modal-dialog">
								    	<button class="uk-modal-close-default" type="button" uk-close></button>
								    	<div class="uk-modal-header">
								            <h2 class="uk-modal-title">Alterar</h2>
								        </div>
								        <div class="uk-modal-body" uk-overflow-auto>
								        	<form class="uk-form-stacked" action="Alterar_computador.php" method="POST">
								        		<input type="hidden"  name="id" id="<?php $resultado['ID'];?>" value ="<?php echo $resultado['ID'];?>">
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Nome do computador</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="nome_pc" type="text" value="<?php echo $resultado['NOME_PC']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Departamento</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="departamento" type="text" value="<?php echo $resultado['DEPARTAMENTO']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">IP</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="IP" type="text" value="<?php echo $resultado['IP']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">HD</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="HD" type="text" value="<?php echo $resultado['HD']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Memoria Ram</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="memoria_ram" type="text" value="<?php echo $resultado['MEMORIA']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Processado</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" id= "pro" name="processador" type="text" value="<?php echo $resultado['PROCESSADOR']; ?>">
								        		   </div>
								        		</div>
								        	</div>
								        	<div class="uk-modal-footer uk-text-right">
								        		<button class="uk-button uk-button-default uk-modal-close" type="button">Cancelar</button>
								        		<input type="submit" name="" class="uk-button uk-button-primary" value="alterar">
								        	</div>
								        </form>
								    </td>
								    <!-- fim do modal de alteracao -->
								    <td>
								    	<a class="uk-button uk-button-default" id="excluir" href="#modal-excluir<?php echo $resultado['ID']; ?>" uk-toggle>Excluir</a>
								    	<div id="modal-excluir<?php echo $resultado['ID']; ?>" uk-modal>
								    		<div class="uk-modal-dialog">
										        <button class="uk-modal-close-default" type="button" uk-close></button>
										        <div class="uk-modal-header" style="background-color: red;">
										            <h2 class="uk-modal-title" style="color: #fff;">Tem certeza que dejesa excluir</h2>
										        </div>
										        <div class="uk-modal-body">
										        	<center>
										        		<h3><?php echo $resultado['NOME_PC']; ?></h3>
										        		<form action="Excluir_computador.php" method="POST">
										        		<input type="hidden"  name="id" id="<?php $resultado['ID'];?>" value ="<?php echo $resultado['ID'];?>">
											        	<button class="uk-button uk-button-Secondary uk-modal-close uk-button-large uk-width-1-3" type="button">Cancelar</button>
											            <button class="uk-button uk-button-primary uk-button-large uk-width-1-3" type="submit">Excluir</button>
											        </center>
										        </div>
										    </form>
										</div>
										</div>
									</td>
								</tr>
							</tbody>
				    <?php } ?>
				</table>
			</div>
		</div>
	</div>
<br><br>
	<footer>
		<br>
			<center><p style="color: white; display: inline;" >℗Copyright GerenciaEmpresa.com</p></center>
			<div style="color: white; float: right; margin-right: 200px; ">
				resdes socias <br><br>
				<img src="img/facebook.png" style="width: 30px; height: 30px; " uk-tooltip="title: GerenreciaMais">
				<img src="img/instagram.png" style="width: 30px; height: 30px;" uk-tooltip="title: @GerenciaSeuSistema">
				<img src="img/whatsapp.svg" style="width: 30px; height: 30px;" uk-tooltip="title: (11) 40028922">

			</div>
	</footer>
	




   <script type="text/javascript" src="js/uikit.min.js"></script>
   <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>

</body>
</html>
