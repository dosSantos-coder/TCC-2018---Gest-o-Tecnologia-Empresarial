<!DOCTYPE html>
<html lang="br">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="Login_v3/image/png" href="Login_v3/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Login_v3/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Login_v3vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/css/util.css">
	<link rel="stylesheet" type="text/css" href="Login_v3/css/main.css">
    <link href="css/uikit.min.css" rel="stylesheet">

<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('Login_v3/images/bg-01.jpg');">
			<div class="wrap-login100">
				<form id="logar" method="POST">
					<span class="login100-form-logo">
						<!-- <i class="zmdi zmdi-landscape"></i> -->
						<img src="logos/icon.png" style="whidth:80px; height:80px;">
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Acesso
					</span>

					<div class="wrap-input100 validate-input" >
						<input class="input100" type="text" name="username" placeholder="Email" id="email">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<input class="input100" type="password" name="pass" placeholder="Senha" id="senha">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="contact100-form-checkbox">
                        <input class="input-checkbox100" id="ckb1" type="checkbox"  onclick="mostrar()">
						<label class="label-checkbox100" for="ckb1">
                            <span>Mostrar senha</span>
						</label>
					</div>


                    <div class="container-login100-form-btn">
			   		    <button  class="login100-form-btn"onclick ="validar_login()">Entrar</button>
		            </div>
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	

    <script type="text/javascript">
	function validar_login(){

	 $('#logar').on("submit",function(event){
	     event.preventDefault()
	       var email = document.getElementById("email").value;
	       var senha = document.getElementById("senha").value;
			if(email == ""){
	            UIkit.notification({
				    message: 'Campo email está vazio !!!',
				    status: 'danger',
				    pos: 'top-right',
				    timeout: 5000
				}).die()
					return false;
					
				}
				else if(senha == ""){
				  UIkit.notification({
				    message: 'Campo senha está vazio !!!',
				    status: 'danger',
				    pos: 'top-right',
				    timeout: 5000
				}).die()
					return false;
					
				}
			else{
				$.post("validar_login.php",
				    {
				        email:email,
				        senha:senha
				    },
				    function(data){
				        if(data == "usuario_invalido"){
				        	
				        	UIkit.notification({
							    message: 'Email ou senha invalido !',
							    status: 'danger',
							    pos: 'top-right',
							    timeout: 5000
							})
							die()
						 }
				        if(data == "ativado"){
				        	window.location.href = "direcionar_tela.php"
				        }
				        if(data =="desativado"){
				        	window.location.href = "Conta_desativada.php"
				        }
				        if(data == "primeiro_acesso"){

				        	UIkit.modal.prompt('<h4>Defina uma nova senha</h4><br>Senha:', '').then(function(senhaa) {

					        		$.post("trocar_senha.php",
									    {
									        email:email,
									        senha:senha,
									        senhaa,senhaa
									    },
									    function(dados){
	                                     if(dados == "novaS_vazio"){
	                                     	UIkit.notification({
											    message: 'Defina uma nova senha por favor !',
											    status: 'danger',
											    pos: 'top-right',
											    timeout: 5000
											})
											die()
	                                     }
	                                     if(dados == "Senha_atualizada"){
	                                     	UIkit.notification({
											    message: 'Senha atualizada com sucesso !',
											    status: 'success',
											    pos: 'top-right',
											    timeout: 5000
											})
											$.post("validar_login.php",
										    {
										        email:email,
										        senha:senhaa
										    },
										    function(dados_vali){
	                                             if(dados_vali == "ativado"){
	                                             	window.location.href = "direcionar_tela.php"
	                                             }
										    })
											die()
	                                        

	                                     }
								    });
								}, function () {
								    console.log('Rejected.')
								});

				  }
				});
				  die()
			 	}
			 	 UIkit.notification.closeAll()
		})

		    UIkit.notification.closeAll()
				}
	
 	 function mostrar() {

          var senha = document.getElementById("senha");
               if(senha.type == "password"){
                senha.type ="text";

               }
               else{
                senha.type = "password";
               }

             }
</script>

<!--===============================================================================================-->
<!--===============================================================================================-->
	<script src="Login_v3/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/vendor/bootstrap/js/popper.js"></script>
	<script src="Login_v3/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/vendor/daterangepicker/moment.min.js"></script>
	<script src="Login_v3/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/js/main.js"></script>
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/uikit.min.js"></script>

</body>
</html>