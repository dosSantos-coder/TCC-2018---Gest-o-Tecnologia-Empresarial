<?php
   include("conexao.php");
   session_start();
 try {
 	 $id = $_POST['id'];


     $sql = $con->prepare("DELETE FROM TB_AUMOXA
            WHERE ID = '$id'");

      $sql->execute();

      header("location: Gerencia_Almoxarifado.php");
      $_SESSION['sucesso_ex'] = "Excluido com sucesso";
 	
 } catch (Exception $e) {
 	echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();

 }
     
      die();
  ?>