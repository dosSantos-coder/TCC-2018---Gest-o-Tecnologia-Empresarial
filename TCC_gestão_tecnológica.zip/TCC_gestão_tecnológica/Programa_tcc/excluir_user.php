<?php 
include("conexao.php");
session_start();

$id = $_POST['id_user'];

 $query = $con->prepare("DELETE FROM TB_FUNCIONARIO WHERE ID = '$id'");
    
     $query->execute();

     header("location: lista_funcionario.php");
     $_SESSION['sucesso_ex_fun'] = "funcionário excluido  com sucesso";



?>