<!DOCTYPE html>
<html>
    <header>
        <?php
	       include("conexao.php");
            session_start();
            if(!isset($_SESSION['logado'])){
              header("location:index.php");
            }
        ?>
	       <title>Ordem de Serviços</title>
	       <link href="css/uikit.min.css" rel="stylesheet">
         <style type="text/css">
             footer {
                background-color: rgb(0, 55, 96);
                display: block;
                min-height: 140px;
                width: 100%;
            }
         </style>
    </header>

    <body>
         <div class="uk-section-primary uk-preserve-color">

        <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

        <nav class="uk-navbar-container" uk-navbar>
                <div class="uk-navbar-left">

                    <ul class="uk-navbar-nav">
                        <li ><a href="Tela_Home_funcionario.php">Home</a></li>
                        <li class="uk-active"><a href="#">Relatar Casos</a></li>
                    </ul>

                </div>
                <div class="uk-navbar-right">

                    <ul class="uk-navbar-nav">
                        
                        <li>
                            <a  href="#">Configurações</a>
                    <div class="uk-navbar-dropdown">
                        <ul class="uk-nav uk-navbar-dropdown-nav">
                            <li class="uk-active"><a href="#">configurações gerais</a></li>
                            <li><a href="troca_senha.php">Seu perfil</a></li>
                            <li class="uk-nav-divider"></li>
                            <li><a href="sair.php">Sair</a></li>
                        </ul>
                    </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>


        <div class="uk-card uk-align-center  uk-card-default uk-width-1-2@m ">
            <div class="uk-card-header">
                <div class="uk-grid-small uk-flex-middle" uk-grid>
                    <div class="uk-width-expand">
                        <h3 class="uk-card-title uk-margin-remove-bottom"  style="display: inline;">Relatos Ordem de Serviço</h3>
                    </div>
                </div>
            </div>
            <form class="uk-form-horizontal uk-margin-large" id="form-relato" method="POST">
            <div class="uk-card-body">
              <input type="hidden" name="nome" value="<?php echo $_SESSION['nome']; ?>" id="nome_relator">
              <input type="hidden" name="id" value="<?php echo $_SESSION['ID']; ?>" id="id_relator">

                  <div class="uk-margin">
                  <label class="uk-form-label" for="form-horizontal-text">Departamento</label>
                      <div class="uk-form-controls">
                         <div class="uk-margin">
                          <select class="uk-select" id="departamento">
                            <option>Financeiro</option>
                            <option>Administração</option>
                            <option>Recursos Humanos (RH)</option>
                            <option>Administrativo</option>
                          </select>
                         </div>
                     </div>

                      <div class="uk-margin">
                        <label class="uk-form-label" for="form-horizontal-text">Gravidade</label>
                       <div class="uk-margin uk-form-controls">
                            <div class="uk-margin">
                             <select class="uk-select" id="gravidade">
                               <option>Normal</option>
                               <option>Urgente</option>
                             </select>
                            </div>
                      </div>
                    </div>

                      <div class="uk-margin">
                        <label class="uk-form-label" for="form-horizontal-text">Titulo</label>
                          <div class="uk-form-controls">
                              <input class="uk-input" id="titulo_relato" type="text" placeholder="Digite o titulo">
                          </div>
                     </div>

                     <div class="uk-margin">
                       <label class="uk-form-label"  for="form-horizontal-text">Ramal</label>
                       <div class="uk-form-controls">
                        <input class="uk-input" id="ramal_relato"  type="text" placeholder="25">
                      </div>
                      </div>

                      <label class="uk-form-label" for="form-horizontal-text">Frequêcia de erro</label>
                      <div class="uk-margin uk-form-controls">
                             <div class="uk-margin">
                              <select class="uk-select" id="frequecia">
                                <option>Esporadicamente</option>
                                <option>Ocasionalmente</option>
                                <option>Sempre</option>
                              </select>
                             </div>
                       </div>

                       <div class="uk-margin">
                         <label class="uk-form-label" for="form-horizontal-text">Versão do Sistema</label>
                           <div class="uk-form-controls">
                               <input class="uk-input" id="versao_relato" type="text" placeholder="Digite a versão">
                           </div>
                      </div>

                     <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Descrição</label>
                        <div class="uk-form-controls">
                           <textarea class="uk-textarea" rows="5" placeholder="Digite a descrição do problema ao qual está relatando" id="descricao_relato"></textarea>
                        </div>
                    </div>
                </div>
              <div class="uk-card-footer">
                <button class="uk-button uk-button-primary" onclick="validar_relato()">Enviar</button>
              </div>
            </form>
          </div>
      </div>
          <br>
          <footer>
            <br>
                  <center><p style="color: white; display: inline;" >℗Copyright GerenciaEmpresa.com</p></center>
                  <div style="color: white; float: right; margin-right: 200px; ">
                    resdes socias <br><br>
                    <img src="img/facebook.png" style="width: 30px; height: 30px; " uk-tooltip="title: GerenreciaMais">
                    <img src="img/instagram.png" style="width: 30px; height: 30px;" uk-tooltip="title: @GerenciaSeuSistema">
                    <img src="img/whatsapp.svg" style="width: 30px; height: 30px;" uk-tooltip="title: (11) 40028922">

                  </div>
          </footer>

          <script type="text/javascript" src="js/uikit.min.js"></script>
          <script type="text/javascript" src="js_personalizado/validar_cad_ti.js"></script>
          <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    </body>
</html>
