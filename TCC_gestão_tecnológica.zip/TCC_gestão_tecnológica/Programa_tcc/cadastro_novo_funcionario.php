<!DOCTYPE html>
<html>
    <header>
        <?php
         include("conexao.php");
            session_start();
            if(!isset($_SESSION['logado'])){
              header("location:index.php");
            }
        ?>
      <style type="text/css">
        footer {
    background-color: rgb(0, 55, 96);
    display: block;
    min-height: 140px;
    width: 100%;
}
      </style>
        <title>Novos Funcionários</title>
        <link href="css/uikit.min.css" rel="stylesheet">
    </header>

    <body>
      <div class="uk-section-primary uk-preserve-color">

      <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

      <nav class="uk-navbar-container" uk-navbar>
              <div class="uk-navbar-left">

                  <ul class="uk-navbar-nav">
                      <li ><a href="Tela_adm.php">Home</a></li>
                      <li class="uk-active"><a href="cadastro_novo_funcionario.php">Novos Funcionário</a></li>
                     <li><a href="lista_funcionario.php">Lista de Funcionários</a></li>
                  </ul>

              </div>
              <div class="uk-navbar-right">

                  <ul class="uk-navbar-nav">
                      <li>
                          <a href="#">Notificações</a>
                          <div class="uk-navbar-dropdown">
                              <ul class="uk-nav uk-navbar-dropdown-nav">
                                  <li class="uk-active"><a href="#">Active</a></li>
                                  <li><a href="#">Item</a></li>
                                  <li class="uk-nav-header">Header</li>
                                  <li><a href="#">Item</a></li>
                                  <li><a href="#">Item</a></li>
                                  <li class="uk-nav-divider"></li>
                                  <li><a href="#">Item</a></li>
                              </ul>
                          </div>
                      </li>
                      <li>
                          <a href="#">Configurações</a>
                          <div class="uk-navbar-dropdown">
                                  <ul class="uk-nav uk-navbar-dropdown-nav">
                                      <li class="uk-active"><a href="#">Configuraçõoes Gerais</a></li>
                                      <li><a href="#">Conta</a></li>
                                      <li class="uk-nav-header">Perfil</li>
                                      <li><a href="#">Configuracoes</a></li>
                                      <li><a href="#">Troca de senha</a></li>
                                      <li class="uk-nav-divider"></li>
                                      <li><a href="sair.php">Sair</a></li>
                                  </ul>
                              </div>
                          </li>
                      </ul>
                  </div>
              </nav>
          </div>
      </div>

      <div class="uk-card uk-align-center  uk-card-default uk-width-1-2@m ">
          <div class="uk-card-header">
              <div class="uk-grid-small uk-flex-middle" uk-grid>
                  <div class="uk-width-expand">
                      <h3 class="uk-card-title uk-margin-remove-bottom"  style="display: inline;">Cadastro Novos Funcionários</h3>
                  </div>
              </div>
          </div>
          <form class="uk-form-horizontal uk-margin-large" id="form_cadnovo" method="POST">
          <div class="uk-card-body">
                <div class="uk-margin">
                <label class="uk-form-label" for="form-horizontal-text">Categoria Funcionário</label>
                    <div class="uk-form-controls">
                       <div class="uk-margin">
                        <select class="uk-select" id="op">
                          <option>Técnico</option>
                          <option>Funcionário</option>
                        </select>
                       </div>
                   </div>

                    <div class="uk-margin">
                      <label class="uk-form-label" for="form-horizontal-text">Nome</label>
                        <div class="uk-form-controls">
                            <input class="uk-input" id="nome_funcionario" type="text" placeholder="Digite o Nome">
                        </div>
                   </div>

                   <div class="uk-margin">
                     <label class="uk-form-label" for="form-horizontal-text">Sobrenome</label>
                       <div class="uk-form-controls">
                           <input class="uk-input" id="nome_sobrenome" type="text" placeholder="Digite o Sobrenome">
                       </div>
                  </div>

                   <div class="uk-margin">
                       <label class="uk-form-label"  for="form-horizontal-text">Idade</label>
                       <div class="uk-form-controls">
                        <input class="uk-input" id="idade"  type="text" placeholder="Digite a Idade">
                      </div>
                  </div>

                     <div class="uk-margin">
                       <label class="uk-form-label" for="form-horizontal-text">Senha</label>
                         <div class="uk-form-controls">
                             <input class="uk-input" id="senha" type="password" placeholder="Digite a senha de acesso">
                         </div>
                    </div>

                    <div class="uk-margin">
                      <label class="uk-form-label" for="form-horizontal-text">Email</label>
                        <div class="uk-form-controls">
                            <input class="uk-input" id="email" type="text" placeholder="Digite o email de acesso">
                        </div>
                   </div>

              </div>
            <div class="uk-card-footer">
              <button class="uk-button uk-button-primary" onclick="validar_cadastro_funcnovo()">Enviar</button>
            </div>
          </form>
        </div>
      </div>
        <footer>
            <br>
              <center><p style="color: white; display: inline;" >℗Copyright GerenciaEmpresa.com</p></center>
              <div style="color: white; float: right; margin-right: 200px; ">
                resdes socias <br><br>
                <img src="img/facebook.png" style="width: 30px; height: 30px; " uk-tooltip="title: GerenreciaMais">
                <img src="img/instagram.png" style="width: 30px; height: 30px;" uk-tooltip="title: @GerenciaSeuSistema">
                <img src="img/whatsapp.svg" style="width: 30px; height: 30px;" uk-tooltip="title: (11) 40028922">

              </div>
          </footer>
        <script type="text/javascript" src="js/uikit.min.js"></script>
        <script type="text/javascript" src="js_personalizado/validar_cadastro_ti.js"></script>
        <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    </body>
</html>
