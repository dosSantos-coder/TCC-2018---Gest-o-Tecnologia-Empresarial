<?php
   include("conexao.php");
   session_start();
    
	   $software = $_POST['software'];
	   $quantidade = $_POST['quantidade'];
	   $Plataforma = $_POST['Plataforma'];
	   $nota_f = $_POST['nota'];
	   $data_compra = $_POST['data_compra'];
	   $chave_p = $_POST['chave_produto'];
	   $fonecedor = $_POST['fornecedor'];
	   
            
             $query = "INSERT INTO TB_SOFTWARE(CHAVE_PRODUTO,QUANTIDADE_LICENCA,PLATAFOMA,NOTA_FISCAL,DATA_COMPRA,NOME_VERSAO,FORNECEDOR)VALUES(?,?,?,?,?,?,?)";
             $sql = $con->prepare($query);
             $sql->bindValue(1,$chave_p);
             $sql->bindValue(2,$quantidade);
             $sql->bindValue(3,$Plataforma);
             $sql->bindValue(4,$nota_f);
             $sql->bindValue(5,$data_compra);
             $sql->bindValue(6,$software);
             $sql->bindValue(7,$fonecedor);

             $sql->execute();
           
           //  header('location: cadastros.php');
	   
	 
		  

	?>