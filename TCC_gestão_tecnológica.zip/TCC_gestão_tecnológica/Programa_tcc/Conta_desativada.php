<!DOCTYPE html>
<html>
<head>
  <?php
  include("conexao.php");
      session_start();
      
      if(!isset($_SESSION['logado'] )){
        header("location:index.php");
     }
  ?>
  
<style>
  
</style>
  <title>conta desativada</title>
  <link href="css/uikit.min.css" rel="stylesheet">
</head>
<body>
  <div uk-alert>
        <a class="uk-alert-close" uk-close onclick="voltar_index()"></a>
        <h3>Erro ao entrar</h3>
        <img src="img/alert_conta.png" style="width: 200px; height: 200px;"><h2 style="display: inline;"> Sua conta foi desativada , fale com o seu reponsavel para ativar sua conta.</h2>
    </div>


   <script type="text/javascript">
     function voltar_index(){
      window.location.href = "index.php";
     }
   </script>
   <script type="text/javascript" src="js/uikit.min.js"></script>
   <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
</body> 

</html>