<?php 
  include("conexao.php");

   $id_relato = $_POST['id_relato'];
   $resumo = $_POST['rusumo_concluido'];

  $query = $con->prepare("UPDATE TB_OS SET STATUS_ERRO = 1 , RESUMO = :resumo WHERE ID = :ID_RELATO");
  $query->bindValue('ID_RELATO',$id_relato);
  $query->bindValue('resumo',$resumo);
  $query->execute();
  
  header("location:meus_relatos.php");
  die();
?>