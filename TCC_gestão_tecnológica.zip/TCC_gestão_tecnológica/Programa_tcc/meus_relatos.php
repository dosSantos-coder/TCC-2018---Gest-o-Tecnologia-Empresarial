<!DOCTYPE html>
<html>
<head>
	<?php
	include("conexao.php");
      session_start();
	 if(!isset($_SESSION['logado'] )){
      	header("location:index.php");
      }
	?>
	<title></title>
	<link href="css/uikit.min.css" rel="stylesheet">
	<style type="text/css">
		footer {
	  background-color: rgb(0, 55, 96);
	  display: block;
	  min-height: 140px;
	  width: 100%;
}
	</style>
</head>
<body>
	<div class="uk-section-primary uk-preserve-color">

    <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

       <nav class="uk-navbar-container" uk-navbar>
		    <div class="uk-navbar-left">

		        <ul class="uk-navbar-nav">
		            <li ><a href="Gerencia_Computadores.php">Home</a></li>
		            <li><a href="Tela_Cadastrar_pc.php">Cadastros</a></li>
		            <li class="uk-active"><a href="todos_relatos.php">Tarefas</a></li>
		        </ul>

		    </div>
		    <div class="uk-navbar-right">

		        <ul class="uk-navbar-nav">
		           <li>
		            	<?php $not = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0");
		            	      $not->execute();
		            	      $tr = $not->rowCount();
		            	      $sql_noty = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0 ORDER BY ID DESC limit 3 "); 
                              $sql_noty->execute();?>
                              <a  href="#"><span style="margin: 3px;" class="uk-badge"><?php echo $tr; ?></span>Notificações</a>
                              <div class="uk-navbar-dropdown" style="overflow: auto;">
                              	<ul class="uk-nav uk-navbar-dropdown-nav">
                              		<?php if($tr > 0){ ?>
                              			<?php while ($linha_noty = $sql_noty->fetch()) {?>
                              				<li class="uk-nav-header">Relato</li>
					                        <li><a href="novos_relatos.php"><?php echo 'ID do relato: '.$linha_noty["ID_RELATO"]."</br> Nome relator: ".$linha_noty["NOME"]." ".$linha_noty["DATA_NOTIFICAO"]." ".$linha_noty["HORA_NOTIFICAO"]; ?></a>
					                        </li>
					                    <?php }
				                    echo "<li class='uk-nav-divider'></li>
				                          <li><a href='todos_notificacao.php'>Mostrar todos Relato</a></li>";
				                }else{
				                	echo "Sem notificação novas";
				                }?>

				                    </ul>
				                </div>
				            </li>
		            <li>
		            	<a  href="#">Configurações</a>
		                <div class="uk-navbar-dropdown">
		                    <ul class="uk-nav uk-navbar-dropdown-nav">
		                        <li class="uk-active"><a href="#">configurações gerais</a></li>
		                        <li><a href="troca_senha.php">Seu perfil</a></li>
		                        <li class="uk-nav-divider"></li>
		                        <li><a href="sair.php">Sair</a></li>
		                    </ul>
		                </div>
		            </li>
		        </ul>
		    </div>
		</nav>
    </div>
    <div class="uk-section">
    	<div class="uk-container">
    		<center><h1 style="color: #fff;">Tarefas</h1></center>
    	</div>
    </div>
</div>
<nav class="uk-navbar-container uk-background-secondary  uk-panel uk-card uk-card-default uk-card-body" style="z-index: 900; height: 80px;" uk-sticky="offset: 80; bottom: #top" uk-navbar>
    <div class="uk-navbar-center">
    	<div class="uk-navbar-center-left"><div>
            <ul class="uk-navbar-nav">
                <li><a href="novos_relatos.php">Novos Casos</a></li>
                
            </ul>
        </div>
    </div>
     <div class="uk-navbar"><div>
            <ul class="uk-navbar-nav">
                <li class="uk-active"><a href="#">Meus casos</a></li>
            </ul>
        </div>
    </div>
    <div class="uk-navbar-center-right">
        <div>
            <ul class="uk-navbar-nav">
                <li><a href="casos_resolvidos.php">casos resolvidos</a></li>
            </ul>
        </div>
         <div class="uk-navbar-center-right">
        <div>
            <ul class="uk-navbar-nav">
                <li><a href="todos_relatos.php">Todos os casos</a></li>
            </ul>
        </div>
    </div>
</div>
</div>
    <div class="uk-navbar-left">

        

    </div>
 </nav>
     <div class="uk-background-default uk-padding">
        	<div class="uk-overflow-auto">
        		<h3 style="display: inline;">Meus relatos</h3>
        	<?php
        	     $id_pessoa = $_SESSION['ID'];
                 $cont_meuR = $con->prepare("SELECT * FROM TB_OS where RELATO_PEGO = 1  and relato_pego_Quem = '$id_pessoa' and STATUS_ERRO  = 0");
                 $cont_meuR->execute();
                                 
        	?>
        		<span class="uk-badge" style="margin-top: -6px;"><?php echo $cont_meuR->rowCount();?></span>
        		<table class="uk-table  uk-table-divider">
						<thead>
							<tr class="table100-head">
								<th>Data e Hora</th>
								<th>ID</th>
								<th>Nome</th>
								<th>Departamento</th>
								<th>Gravidade</th>
								<th>Frequêcia</th>
								<th>Data atulizada</th>
								<th>Hora atualizada</th>
								<th>informações</th>
								<th>concluir</th>

							</tr>
						</thead>
					<?php
						 $pagina_atual =  filter_input(INPUT_GET,'pagina_meus_casos',
                                  FILTER_SANITIZE_NUMBER_INT);
                                 $pagina = (!empty($pagina_atual)) ? $pagina_atual : 1;
                                 $quanti_result_pg = 10;

                                 $inicio = ($quanti_result_pg * $pagina) - $quanti_result_pg;

								 //recebe o numero da pagina

				         
						       	$sql_erro = $con->prepare("SELECT * FROM TB_OS where RELATO_PEGO = 1 and relato_pego_Quem = '$id_pessoa' and  STATUS_ERRO  = 0 order by  DATA_ENVIO desc LIMIT $inicio,$quanti_result_pg ");
						     	 $sql_erro->execute();
                                   
                      
		                        while ($linha_erro = $sql_erro->fetch()) {?>
						<tbody>
								<tr>
									<td class="column1"><?php echo $linha_erro['DATA_ENVIO'];?> <?php echo $linha_erro['HORA_ENVIO'] ?></td>
									<td class="column2"><?php echo $linha_erro['ID'];?></td>
									<td class="column3"><?php echo $linha_erro['NOME_MANDO']; ?></td>
									<td class="column4"><?php echo $linha_erro['DEPARTAMENTO'] ?></td>
									<td class="column5"><?php echo $linha_erro['GRAVIDADE'] ?></td>
									<td class="column6"><?php echo $linha_erro['FREQUECIA'];?></td>
									<td class="column8"><?php echo $linha_erro['DATA_ATUALIZACAO'];?></td>
									<td class="column9"><?php echo $linha_erro['HORA_ENVIO'] ?></td>
                                    <td class="column10">
                                    	<button class="uk-button uk-button-default uk-margin-small-right" type="button" uk-toggle="target: #modal-info<?php echo $linha_erro['ID'];?>">Informações</button>

										<div id="modal-info<?php echo $linha_erro['ID'];?>" uk-modal>
										    <div class="uk-modal-dialog uk-modal-body">
										        <h2 class="uk-modal-title">Informações</h2>
										        <br>
										        <center><p style="display: inline;">Titulo: </p><?php echo $linha_erro['TITULO']; ?></center>
                                                <div>
                                                	<br>
                                                   <p style="display: inline;">Descrição: </p><?php echo $linha_erro['DESCRICAO']; ?>
                                               </div>
                                               <form method="POST" action="adicionar_relato.php">
                                                 <p class="uk-text-right">
										         
										       </form>
										   </p>
										</div>
									</div>
								</td>
								<td><button class="uk-button uk-button-primary" type="button" uk-toggle="target: #modal-concluir<?php echo $linha_erro['ID'];?>">Concluir</button></td>
								<div id="modal-concluir<?php echo $linha_erro['ID'];?>" uk-modal>
									 <div class="uk-modal-dialog uk-modal-body">
									 	 <h2 class="uk-modal-title">Concluir ?</h2>
									 	 <hr>
									 	  <form action="concluir_relato.php" method="POST">
									 	  	     <p class="uk-text-right">
									 	  	     	<div class="uk-margin">
									 	  	     		<textarea class="uk-textarea" rows="5" placeholder="relatorio" name="rusumo_concluido"></textarea>
                                                   	    <input type="hidden" name="id_relato" id="id_erro" value ="<?php echo $linha_erro['ID'];?>">
											        </div>
											        <hr>
									 	  	     	<input type="submit" name="" class="uk-button uk-button-primary">
									 	  	     </p>
									 	  </form>
									 </div>
								</div>

							</tr>
						</tbody>
						  <?php }?>
					</table>
				</div>
			</div>
	 <?php $r_pg = $con->prepare("SELECT COUNT(ID) AS NUM_ROWS FROM TB_OS where RELATO_PEGO = 1 and relato_pego_Quem = '$id_pessoa' and  STATUS_ERRO  = 0  ");
                                 $r_pg->execute();
                                 $row_erro = $r_pg->fetch();
                                 $q_pg_erro = ceil($row_erro['NUM_ROWS'] / $quanti_result_pg );
                                 $max_links = 5;  ?>
                                 <ul class="uk-pagination uk-flex-center" uk-margin>
								    <li><a class="page-link" href="meus_relatos.php?pagina_meus_casos=1"><span uk-pagination-previous></span></a></li><?php for($pagina_ant = $pagina - $max_links; $pagina_ant <= $pagina - 1; $pagina_ant++){
                                      if($pagina_ant >=1){
                                      ?></li>
								    <li><a class="page-link" href="meus_relatos.php?pagina_meus_casos=<?php echo $pagina_ant;?>"><?php echo $pagina_ant;?></a></li>
								    <li>
								    <?php }}?>
								    <li><a class="page-link" href="meus_relatos.php?pagina_meus_casos=<?php echo $pagina;?>"><?php echo $pagina;?></a></li>
								     <?php for($pg_dps = $pagina + 1; $pg_dps <= $pagina + $max_links; $pg_dps++){
                                      if($pg_dps <= $q_pg_erro){
                                      ?>
								    <li> <a class="page-link" href="meus_relatos.php?pagina_meus_casos=<?php echo $pg_dps;?>"><?php echo $pg_dps;?></a></li>
								    <?php }}?>
								    <li> <a class="page-link" href="meus_relatos.php?pagina_meus_casos=<?php echo $q_pg_erro;?>"><span uk-pagination-next></span></a></li>
								</ul>
								<footer>
									<br>
									<center><p style="color: white; display: inline;" >℗Copyright GerenciaEmpresa.com</p></center>
									<div style="color: white; float: right; margin-right: 200px; ">
										resdes socias <br><br>
										<img src="img/facebook.png" style="width: 30px; height: 30px; " uk-tooltip="title: GerenreciaMais">
										<img src="img/instagram.png" style="width: 30px; height: 30px;" uk-tooltip="title: @GerenciaSeuSistema">
										<img src="img/whatsapp.svg" style="width: 30px; height: 30px;" uk-tooltip="title: (11) 40028922">

									</div>
								</footer>
	
 <script type="text/javascript" src="js/uikit.min.js"></script>
</body>
</html>