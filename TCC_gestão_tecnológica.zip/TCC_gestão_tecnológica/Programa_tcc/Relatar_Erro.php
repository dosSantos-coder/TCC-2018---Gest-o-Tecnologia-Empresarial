<?php
	include("conexao.php");
    
   $departamento = $_POST['departamento'];
   echo $nome = $_POST['nome'];
  echo $id = $_POST['id'];
  echo   $gravidade = $_POST['gravidade'];
  echo  $titulo = $_POST['titulo'];
  echo  $ramal = $_POST['ramal'];
   echo $Frequecia = $_POST['Frequecia'];
  echo  $descricao = $_POST['descricao'];
  echo $versao = $_POST['versao'];
 
  date_default_timezone_set('America/Sao_Paulo');
  echo  $hora = date('H:i');
  echo  $data = date('d/m/Y');

if($_POST == ""){
      echo 'vazio';
  }else{

    $query_relato = "  INSERT INTO TB_OS(TITULO,DEPARTAMENTO,GRAVIDADE,RAMAL,FREQUECIA,VERSAO,DESCRICAO,NOME_MANDO,ID_MANDO,DATA_ENVIO,HORA_ENVIO,RELATO_PEGO,STATUS_ERRO)VALUES
   (?,?,?,?,?,?,?,?,?,?,?,0,2)";
    $sql = $con->prepare($query_relato);
    $sql->bindValue(1,$titulo);
    $sql->bindValue(2,$departamento);
    $sql->bindValue(3,$gravidade);
    $sql->bindValue(4,$ramal);
    $sql->bindValue(5,$Frequecia);
    $sql->bindValue(6,$versao);
    $sql->bindValue(7,$descricao);
    $sql->bindValue(8,$nome);
    $sql->bindValue(9,$id);
    $sql->bindValue(10,$data);
    $sql->bindValue(11,$hora);
    $sql->execute();

 $s = $con->prepare("SELECT ID FROM TB_OS ORDER BY ID DESC limit 1");
     $s->execute();
     $id_o = $s->fetch();
     $id_mando =   $id_o['ID'];
    $notificacao = "INSERT INTO NOTIFICACAO(NOME,DATA_NOTIFICAO,HORA_NOTIFICAO,VIZUALIZAR,ID_RELATO)VALUES(?,?,?,?,?)";
    $execute = $con->prepare($notificacao);
    $execute->bindValue(1,$nome);
    $execute->bindValue(2,$data);
    $execute->bindValue(3,$hora);
    $execute->bindValue(4,0);
    $execute->bindValue(5,$id_mando);

    $execute->execute();
    die();

}
