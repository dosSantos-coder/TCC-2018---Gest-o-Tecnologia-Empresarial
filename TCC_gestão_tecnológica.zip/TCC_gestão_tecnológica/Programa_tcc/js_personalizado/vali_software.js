function validar_cadastro_software1(){
  $('#cadastrar_software').on("submit",function(event){
         event.preventDefault()
            var software = document.getElementById("software").value;
            var quantidade = document.getElementById("q").value;
            var Plataforma = document.getElementById("Plataforma").value;
            var nota = document.getElementById("n").value;
            var data_compra = document.getElementById("data_compra").value;
            var chave_produto = document.getElementById("chave_produto").value;
            var fornecedor = document.getElementById("fornecedor").value;
            if(software == "")
			{
			 
			  UIkit.notification({
			    message: 'Algum campo esta vazio!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
			  return false;
			}
			if(quantidade == "")
			{
			   UIkit.notification({
			    message: 'Algum campo esta vazio!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(Plataforma == "")
			{
			   UIkit.notification({
			    message: 'Algum campo esta vazio!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(nota == "")
			{
			   UIkit.notification({
			    message: 'Algum campo esta vazio!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(data_compra == "")
			{
			  var erro = document.getElementById("erro3");
			  div.className = "alert alert-danger"
			  erro.innerText ="Data da compra esta vazio!";
				return false;
				
			}
			if(chave_produto == "")
			{
			  UIkit.notification({
			    message: 'Algum campo esta vazio!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(fornecedor == ""){
				var erro = document.getElementById("erro3");
				div.className = "alert alert-danger"
			    erro.innerText ="Fornecedor esta vazio!";
				return false;
			}$.ajax({
			  method: "POST",
			  url: "cadastro_software.php",
			  data:{
			    software:software,
			  	quantidade:quantidade,
			  	Plataforma: Plataforma,
			  	nota:nota,
			  	data_compra:data_compra,
			  	chave_produto:chave_produto,
			  	fornecedor:fornecedor


                 }
				 }).done(function(){ 
				    UIkit.notification({
				    message: 'Eviado com Sucesso!',
				    status: 'success',
				    timeout: 5000
				});
                  $("#software").val("")
                  $("#q").val("")
                  $("#Plataforma").val("")
                  $("#n").val("")
                  $("#data_compra").val("")
                  $("#chave_produto").val("")
                  $("#fornecedor").val("")



                  
				 })

		})
			

				//document.getElementById("cadastro_software.php").submit();
			

      }