  function validar_cadastro_pc(){
	 	
	 	$("#cadastro_pc").submit(function(event){
	 	  event.preventDefault()
	 		var obj = this;
	 		var form = $(obj);
	 		var dados = new FormData(obj);


	 		$.ajax({
	 			url: form.attr('action'),
	 			type:form.attr('method'),
	 			data: dados,
	 			processData:false,
	 			cache:false,
	 			contentType:false,
	 			
	 		}).done(function(data){
             if(data =="vazio"){
             	
             	 UIkit.notification({
				    message: 'Algum Campo está vazio !!!',
				    status: 'danger',
				    pos: 'top-right',
				    timeout: 5000
				}).die()
			  }
             else{
             		UIkit.notification({
				    message: 'Enviado com Sucesso!',
				    status: 'success',
				    timeout: 5000
				}).die()
				       	
             }
            
 		  })
            document.getElementById("nome_pc").value = ""
            document.getElementById("departamento").value = ""
            document.getElementById("ip").value = ""
            document.getElementById("hd").value = ""
            document.getElementById("memoria_ram").value = ""
            document.getElementById("processador").value = ""
	 		die()
	 	})
           
		   UIkit.notification.closeAll()

	 };

function validar_cadastro_software(){

  $("#cadastrar_soft").on("submit",function(event){
         event.preventDefault()
            var software = document.getElementById("software").value;
            var quantidade = document.getElementById("q").value;
            var Plataforma = document.getElementById("Plataforma").value;
            var nota = document.getElementById("n").value;
            var data_compra = document.getElementById("data_compra").value;
            var chave_produto = document.getElementById("chave_produto").value;
            var fornecedor = document.getElementById("fornecedor").value;
            if(software == "")
			{
			 
			  UIkit.notification({
			    message: 'Campo Software está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
			  return false;
			
			}
			if(quantidade == "")
			{
			   UIkit.notification({
			    message: 'Campo Quantidade está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
				return false;
				
				
			}
			if(chave_produto == "")
			{
			  UIkit.notification({
			    message: 'Campo Chave do Produto está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die()
				return false;
				
			}
			if(Plataforma == "")
			{
			   UIkit.notification({
			    message: 'Campo Plataforma está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();;
				return false;
				
			}
			if(nota == "")
			{
			   UIkit.notification({
			    message: 'Campo Nota está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();;
				return false;
				
			}
			
			
			if(fornecedor == ""){
	      UIkit.notification({
			    message: 'Campo Fornecedor está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
				return false;
			}
			if(data_compra == "")
			{
			   UIkit.notification({
			    message: 'Campo Data da Compra está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die()
				return false;
				
			}$.ajax({
			  method: "POST",
			  url: "cadastro_software.php",
			  data:{
			    software:software,
			  	quantidade:quantidade,
			  	Plataforma: Plataforma,
			  	nota:nota,
			  	data_compra:data_compra,
			  	chave_produto:chave_produto,
			  	fornecedor:fornecedor


                 }
				 }).done(function(){ 
				    UIkit.notification({
				    message: 'Enviado com Sucesso!',
				    status: 'success',
				    timeout: 5000
				});
                  $("#software").val("")
                  $("#q").val("")
                  $("#Plataforma").val("")
                  $("#n").val("")
                  $("#data_compra").val("")
                  $("#chave_produto").val("")
                  $("#fornecedor").val("")

      

                  
				 }).die();
				

		})
			

    UIkit.notification.closeAll()
		//document.getElementById("cadastro_software.php").submit();
			

      }
       function validar_cadastro_aumo(){
  $('#cadastros_almo').on("submit",function(event){

   event.preventDefault()
          var nome_p = $("#nome_p").val();
          var quantidade = $("#quantidade").val();
          var fonecedor = $("#fonecedor1").val();
          var prateleira = $("#prateleira").val();
          var nota = $("#nota1").val();
          var descricao = $("#descricao").val();
          var usado_novo = $("#usado_novo").val();
          
 
          if(nome_p == "")
          {

		  UIkit.notification({
			    message: 'Campo Nome do Produto está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
			return false;
			
		}
		if(quantidade == "")
		{
		  UIkit.notification({
			    message: 'Campo Quantidade está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
			return false;
			
		}
		if(fonecedor == "")
		{
		   UIkit.notification({
			    message: 'Campo Fornecedor está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
			return false;
			
		}
		if(prateleira == "")
		{
		 UIkit.notification({
			    message: 'Campo Prateleira está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
			return false;
			
		}
		if(nota == "")
		{
		    UIkit.notification({
			    message: 'Campo Nota está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
			return false;
			
		}
		if(descricao == "")
		{
		 UIkit.notification({
			    message: 'Campo Descrição está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
			return false;
			
		}
		 $.ajax({
			  method: "POST",
			  url: "cadastros_almo.php",
			  data:{
			    nome_p:nome_p,
			  	quantidade:quantidade,
			  	fonecedor: fonecedor,
			  	prateleira:prateleira,
			  	nota:nota,
			  	descricao:descricao,
			  	usado_novo:usado_novo

                 }
				 }).done(function(){ 
				 	 UIkit.notification({
				    message: 'Enviado com Sucesso!',
				    status: 'success',
				    timeout: 5000
				});
                  $("#nome_p").val("")
                  $("#quantidade").val("")
                  $("#fonecedor1").val("")
                  $("#prateleira").val("")
                  $("#nota1").val("")
                  $("#descricao").val("")

                  
				 }).die();

		})
		 UIkit.notification.closeAll()

		
}
function validar_cadastro_funcnovo(){
  $('#form_cadnovo').on("submit",function(event){
    event.preventDefault()
           var nome_funcionario = $("#nome_funcionario").val();
           var nome_sobrenome = $("#nome_sobrenome").val();
           var op = $("#op").val();
           var idade = $("#idade").val();
           var senha = $("#senha").val();
           var email = $("#email").val();

           if(op == "")
           {
           UIkit.notification({
           message: 'Campo de seleção de categoria está vazio!',
           status: 'danger',
           pos: 'top-right',
           timeout: 5000
           }).die();
           return false;
           }

             if(nome_funcionario == "")
             {
         		  UIkit.notification({
         			    message: 'Campo Nome está vazio!',
         			    status: 'danger',
         			    pos: 'top-right',
         			    timeout: 5000
         			}).die();
         			return false;
              }

                if(nome_sobrenome == "")
                {

                  UIkit.notification({
                  message: 'Campo Sobrenome está vazio!',
                  status: 'danger',
                  pos: 'top-right',
                  timeout: 5000
                }).die();
                return false;
                }

                  if(idade == "")
                  {
                  UIkit.notification({
                  message: 'Campo Idade está vazio!',
                  status: 'danger',
                  pos: 'top-right',
                  timeout: 5000
                  }).die();
                  return false;
                  }

                    if(senha == "")
                    {
                    UIkit.notification({
                    message: 'Campo Senha está vazio!',
                    status: 'danger',
                    pos: 'top-right',
                    timeout: 5000
                    }).die();
                    return false;
                    }

                      if(email == "")
                      {
                      UIkit.notification({
                      message: 'Campo Email está vazio!',
                      status: 'danger',
                      pos: 'top-right',
                      timeout: 5000
                      }).die();
                      return false;
                      }

                      $.ajax({
                        method:"POST",
                        url:"cadastro_funcnovo.php",
                        data:{
                          nome_funcionario:nome_funcionario,
                          nome_sobrenome:nome_sobrenome,
                          op: op,
                          idade:idade,
                          senha:senha,
                          email:email
                        }
                         }).done(function(){
                           UIkit.notification({
                            message: 'Enviado com Sucesso!',
                            status: 'success',
                            timeout: 5000
                        });
                           $("#nome_funcionario").val("")
                           $("#nome_sobrenome").val("")
                          
                           $("#idade").val("")
                           $("#senha").val("")
                           $("#email").val("")
                         }).die();
            })
  	   UIkit.notification.closeAll()

}
 function busca_todos_relatos(){
	 	
	 	// $("#busca_todos").submit(function(){
	 	// 	var obj = this;
	 	// 	var form = $(obj);
	 	// 	var dados = new FormData(obj);


	 	// 	$.ajax({
	 	// 		url: form.attr('action'),
	 	// 		type:form.attr('method'),
	 	// 		data: dados,
	 	// 		processData:false,
	 	// 		cache:false,
	 	// 		contentType:false,
	 			
	 	// 	}).done(function(data){
   //           if(data =="vazio"){
   //           	 UIkit.notification({
			// 	    message: 'nem uma busca foi feita !!!',
			// 	    status: 'danger',
			// 	    pos: 'top-right',
			// 	    timeout: 5000
			// 	});

   //           }
   //           else{
   //           	$("#busca").innerHTML = data
   //           }
             
	 	// 	return false; 
	 	// }).die()

function validar_relato(){

    $('#form-relato').on("submit",function(event){

     event.preventDefault()
         var nome_relator = $('#nome_relator').val()
         var departamento = $('#departamento').val()
         var id = $('#id_relator').val()
         var gravidade = $('#gravidade').val()
         var titulo = $('#titulo_relato').val()
         var ramal = $('#ramal_relato').val()
         var versao = $('#versao_relato').val()
         var descricao = $('#descricao_relato').val()
         var frequecia = $('#frequecia').val()
        
         
         

         if(nome_relator == ""){
 
            UIkit.notification({
			    message: 'Algum campo esta vazio!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false

         }else if(id == ""){
           UIkit.notification({
			    message: 'Algum campo esta vazio!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false

         }else if(titulo == ""){
               
            UIkit.notification({
			    message: 'Campo Título está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();

         return false;
         }
        
         else if(ramal == ""){
            
            UIkit.notification({
			    message: 'Campo Ramal está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false
         }
        
        else if(versao == ""){
          
            UIkit.notification({
			    message: 'Campo Versão do Sistema está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false
         }
        
         else if(descricao == ""){
              
                UIkit.notification({
			    message: 'Campo Descrição está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false
         }else{
          //ajax enviando form sem recarega a pagina
                $.ajax({
                  method: "POST",
                  url: "Relatar_Erro.php",
                  data:{
                    departamento:departamento,
                    nome:nome_relator,
                    id: id,
                    gravidade:gravidade,
                    titulo:titulo,
                    ramal:ramal,
                    versao:versao,
                    descricao:descricao,
                    Frequecia:frequecia
                  }
         }).done(function(){
           UIkit.notification({
				    message: 'Enviado com Sucesso!',
				    status: 'success',
				    timeout: 5000
				});
            $("#titulo_relato").val('')
            $("#ramal_relato").val('')
            $("#versao_relato").val('')
            $("#descricao_relato").val('')
             

          }).die()
        }
           
 })   
          UIkit.notification.closeAll()     
}
 	$('#busca_todos').on("submit",function(event){
      event.preventDefault()
       var buscar_caso = $("#text_b").val()
       $.ajax({
            method:"POST",
            url:"buscar_todos_relatos.php",
            data:{
             buscar_caso:buscar_caso
            }
             }).done(function(){
                $.get("buscar_todos_relatos.php", function(data, status){
       		        document.getElementById("busca").innerHTML =   data
            });
            })
        })
	 };
 var c
(function(){
        c  = document.getElementById("todos_rela");
        c.style.display = "none";
})();

function fechar(){
    c.style.display = "block"
	document.getElementById("busca").remove()
	document.getElementById("titulo_b").remove()
}
