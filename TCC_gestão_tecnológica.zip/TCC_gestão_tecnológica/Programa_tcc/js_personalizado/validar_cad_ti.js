function validar_cadastro_pc(){
	 	var div =  document.getElementById("mostrar_pc");
  $('#cadastro_pc').on("submit",function(event){
         event.preventDefault()
          var n_pc = document.getElementById("nome_pc").value;
          var departamento = document.getElementById("departamento").value;
          var ip = document.getElementById("ip").value;
          var hd = document.getElementById("hd").value;
          var memoria_ram = document.getElementById("memoria_ram").value;
          var processador = document.getElementById("processador").value;
          var img = document.getElementByName("img").value;
          
          if(n_pc == "")
			{

			  UIkit.notification({
			    message: 'Campo Nome do PC está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(departamento == "")
			{
			 UIkit.notification({
			    message: 'Campo Descrição está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(ip == "")
			{
			   UIkit.notification({
			    message: 'Campo IP está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(hd == "")
			{
			   UIkit.notification({
			    message: 'Campo HD está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(memoria_ram == "")
			{
			   UIkit.notification({
			    message: 'Campo Memoria RAM está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(processador == "")
			{
			  UIkit.notification({
			    message: 'Campo Processador está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}$.ajax({
			  method: "POST",
			  url: "cadastro_pc.php",
			  data:{
			    n_pc:n_pc,
			  	departamento:departamento,
			  	ip: ip,
			  	hd:hd,
			  	memoria_ram:memoria_ram,
			  	processador:processador

                 }
				 }).done(function(){ 
				 	 UIkit.notification({
				    message: 'Enviado com Sucesso!',
				    status: 'success',
				    timeout: 5000
				});
                  $("#nome_pc").val("")
                  $("#departamento").val("")
                  $("#ip").val("")
                  $("#hd").val("")
                  $("#memoria_ram").val("")
                  $("#processador").val("")

                  
				 })

		})
			

				//document.getElementById("cadastro_pc.php").submit();
}

function validar_cadastro_software(){

  $("#cadastrar_soft").on("submit",function(event){
         event.preventDefault()
            var software = document.getElementById("software").value;
            var quantidade = document.getElementById("q").value;
            var Plataforma = document.getElementById("Plataforma").value;
            var nota = document.getElementById("n").value;
            var data_compra = document.getElementById("data_compra").value;
            var chave_produto = document.getElementById("chave_produto").value;
            var fornecedor = document.getElementById("fornecedor").value;
            if(software == "")
			{
			 
			  UIkit.notification({
			    message: 'Campo Software está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
			  return false;
			}
			if(quantidade == "")
			{
			   UIkit.notification({
			    message: 'Campo Quantidade está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(Plataforma == "")
			{
			   UIkit.notification({
			    message: 'Campo Plataforma está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(nota == "")
			{
			   UIkit.notification({
			    message: 'Campo Nota está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(data_compra == "")
			{
			   UIkit.notification({
			    message: 'Campo Data da Compra está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(chave_produto == "")
			{
			  UIkit.notification({
			    message: 'Campo Chave do Produto está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
				
			}
			if(fornecedor == ""){
	      UIkit.notification({
			    message: 'Campo Fornecedor está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
				return false;
			}$.ajax({
			  method: "POST",
			  url: "cadastro_software.php",
			  data:{
			    software:software,
			  	quantidade:quantidade,
			  	Plataforma: Plataforma,
			  	nota:nota,
			  	data_compra:data_compra,
			  	chave_produto:chave_produto,
			  	fornecedor:fornecedor


                 }
				 }).done(function(){ 
				    UIkit.notification({
				    message: 'Enviado com Sucesso!',
				    status: 'success',
				    timeout: 5000
				});
                  $("#software").val("")
                  $("#q").val("")
                  $("#Plataforma").val("")
                  $("#n").val("")
                  $("#data_compra").val("")
                  $("#chave_produto").val("")
                  $("#fornecedor").val("")



                  
				 })

		})
			

				//document.getElementById("cadastro_software.php").submit();
			

      }
       function validar_cadastro_aumo(){
  $('#cadastros_almo').on("submit",function(event){

         event.preventDefault()
          var nome_p = $("#nome_p").val();
          var quantidade = $("#quantidade").val();
          var fonecedor = $("#fonecedor1").val();
          var prateleira = $("#prateleira").val();
          var nota = $("#nota1").val();
          var descricao = $("#descricao").val();
          var usado_novo = $("#usado_novo").val();
         
          if(nome_p == "")
          {

		  UIkit.notification({
			    message: 'Campo Nome do Produto está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
			return false;
			
		}
		if(quantidade == "")
		{
		  UIkit.notification({
			    message: 'Campo Quantidade está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
			return false;
			
		}
		if(fonecedor == "")
		{
		   UIkit.notification({
			    message: 'Campo Fornecedor está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
			return false;
			
		}
		if(prateleira == "")
		{
		 UIkit.notification({
			    message: 'Campo Prateleira está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
			return false;
			
		}
		if(nota == "")
		{
		    UIkit.notification({
			    message: 'Campo Nota está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
			return false;
			
		}
		if(descricao == "")
		{
		 UIkit.notification({
			    message: 'Campo Descrição está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			});
			return false;
			
		}
		 $.ajax({
			  method: "POST",
			  url: "cadastros_almo.php",
			  data:{
			    nome_p:nome_p,
			  	quantidade:quantidade,
			  	fonecedor: fonecedor,
			  	prateleira:prateleira,
			  	nota:nota,
			  	descricao:descricao,
			  	usado_novo:usado_novo

                 }
				 }).done(function(){ 
				 	 UIkit.notification({
				    message: 'Enviado com Sucesso!',
				    status: 'success',
				    timeout: 5000
				});
                  $("#nome_p").val("")
                  $("#quantidade").val("")
                  $("#fonecedor1").val("")
                  $("#prateleira").val("")
                  $("#nota1").val("")
                  $("#descricao").val("")

                  
				 })

		})
		    
		
}
function validar_relato(){

    $('#form-relato').on("submit",function(event){

     event.preventDefault()
         var nome_relator = $('#nome_relator').val()
         var departamento = $('#departamento').val()
         var id = $('#id_relator').val()
         var gravidade = $('#gravidade').val()
         var titulo = $('#titulo_relato').val()
         var ramal = $('#ramal_relato').val()
         var versao = $('#versao_relato').val()
         var descricao = $('#descricao_relato').val()
         var frequecia = $('#frequecia').val()
        
         
         

         if(nome_relator == ""){
 
            UIkit.notification({
			    message: 'Algum campo esta vazio!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false

         }else if(id == ""){
           UIkit.notification({
			    message: 'Algum campo esta vazio!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false

         }else if(titulo == ""){
               
            UIkit.notification({
			    message: 'Campo Título está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();

         return false;
         }
        
         else if(ramal == ""){
            
            UIkit.notification({
			    message: 'Campo Ramal está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false
         }
        
        else if(versao == ""){
          
            UIkit.notification({
			    message: 'Campo Versão do Sistema está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false
         }
        
         else if(descricao == ""){
              
                UIkit.notification({
			    message: 'Campo Descrição está vazio !!!',
			    status: 'danger',
			    pos: 'top-right',
			    timeout: 5000
			}).die();
               return false
         }else{
          //ajax enviando form sem recarega a pagina
                $.ajax({
                  method: "POST",
                  url: "Relatar_Erro.php",
                  data:{
                    departamento:departamento,
                    nome:nome_relator,
                    id: id,
                    gravidade:gravidade,
                    titulo:titulo,
                    ramal:ramal,
                    versao:versao,
                    descricao:descricao,
                    Frequecia:frequecia
                  }
         }).done(function(){
           UIkit.notification({
				    message: 'Enviado com Sucesso!',
				    status: 'success',
				    timeout: 5000
				});
            $("#titulo_relato").val('')
            $("#ramal_relato").val('')
            $("#versao_relato").val('')
            $("#descricao_relato").val('')
             

          }).die()
        }
           
 })   
               UIkit.notification.closeAll()
}