<?php

    $bdservidor = 'mysql:host=localhost;dbname=BD_GERENCIA';
	$bdusuario = 'root';
	$bdsenha = '';

 try{
		$con = new PDO($bdservidor, $bdusuario, $bdsenha);
   }catch(PDOException $e){
	echo 'erro'.$e->getCode().'mesasgem'.$e->getMessage;
	die();
	}


 ?>