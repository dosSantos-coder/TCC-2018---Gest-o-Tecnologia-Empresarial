<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="css/uikit.min.css" rel="stylesheet">
	<?php
	include("conexao.php");
     session_start();
    if(!isset($_SESSION['logado'] )){
      	header("location:index.php");
      }
	?>
	<style type="text/css">
		footer {
	  background-color: rgb(0, 55, 96);
	  display: block;
	  min-height: 140px;
	  width: 100%;
}
	</style>
</head>
<body>
	<div class="uk-section-primary uk-preserve-color">

    <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

       <nav class="uk-navbar-container" uk-navbar>
		    <div class="uk-navbar-left">

		        <ul class="uk-navbar-nav">
		            <li><a href="Gerencia_Computadores.php">Home</a></li>
		            <li  class="uk-active"><a href="#">Cadastros</a></li>
		            <li><a href="novos_relatos.php">Tarefas</a></li>
		        </ul>

		    </div>
		    <div class="uk-navbar-right">

		        <ul class="uk-navbar-nav">
		            <li>
		            	<?php $not = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0");
		            	      $not->execute();
		            	      $tr = $not->rowCount();
		            	      $sql_noty = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0 ORDER BY ID DESC limit 4 "); 
                              $sql_noty->execute();?>
                              <a  href="#"><span style="margin: 3px;" class="uk-badge"><?php echo $tr; ?></span>Notificações</a>
                              <div class="uk-navbar-dropdown" style="overflow: auto;">
                              	<ul class="uk-nav uk-navbar-dropdown-nav">
                              		<?php if($tr > 0){ ?>
                              			<?php while ($linha_noty = $sql_noty->fetch()) {?>
                              				<li class="uk-nav-header">Relato</li>
					                        <li><a href="novos_relatos.php"><?php echo 'ID do relato: '.$linha_noty["ID_RELATO"]."</br> Nome relator: ".$linha_noty["NOME"]." ".$linha_noty["DATA_NOTIFICAO"]." ".$linha_noty["HORA_NOTIFICAO"]; ?></a>
					                        </li>
					                    <?php }
				                    echo "<li class='uk-nav-divider'></li>
				                          <li><a href='todos_notificacao.php'>Mostrar todos Relato</a></li>";
				                }else{
				                	echo "Sem notificação novas";
				                }?>

				                    </ul>
				                </div>
				            </li>
		            <li>
		            	<a  href="#">Configurações</a>
		                <div class="uk-navbar-dropdown">
		                    <ul class="uk-nav uk-navbar-dropdown-nav">
		                        <li class="uk-active"><a href="#">configurações gerais</a></li>
		                        <li><a href="troca_senha.php">Seu perfil</a></li>
		                        <li class="uk-nav-divider"></li>
		                        <li><a href="sair.php">Sair</a></li>
		                    </ul>
		                </div>
		            </li>
		        </ul>
		    </div>
		</nav>
    </div> 
</div>
<div class="uk-card uk-align-center  uk-card-default uk-width-1-2@m ">
    <div class="uk-card-header">
        <div class="uk-grid-small uk-flex-middle" uk-grid>
            <div class="uk-width-expand">
                <h3 class="uk-card-title uk-margin-remove-bottom"  style="display: inline;">Almoxarifado</h3>
                <div class="uk-offcanvas-conten uk-align-right">
                		<button class="uk-button uk-button-default uk-margin-small-right" type="button" uk-toggle="target: #offcanvas-reveal">Listas de cadastros</button>
							<div id="offcanvas-reveal" uk-offcanvas="mode: reveal; overlay: true">
							<div class="uk-offcanvas-bar">
								<button class="uk-offcanvas-close" type="button" uk-close></button>
								<ul class="uk-nav uk-nav-default">
									<li style="font-size: 34px;" class="uk-active">Lista de cadastros</li><br>
						            <li style="font-size: 15px;"><a href="Tela_cadastrar_pc.php"><span class="uk-margin-small-right" uk-icon="icon: table"><img src="
						            	imagens/pc2.PNG" style="width: 20px; height: 20px;"></span>Cadastrar computadores</a></li>
						            <li class="uk-nav-divider"></li>
						            <li  style="font-size: 15px;"><a href="#"><img src="
						            	imagens/caixa.PNG" style="width: 20px; height: 20px;"><span class="uk-margin-small-right" uk-icon="icon: thumbnails"></span>Cadastrar almoxarifado</a></li>
						            <li class="uk-nav-divider"></li>
						            <li  style="font-size: 15px;"><a href="Tela_cadastrar_software.php"><span class="uk-margin-small-right" uk-icon="icon: trash"><img src="imagens/software.PNG" style="width: 20px; height: 20px;"></span>Cadatrar software</a></li>
						        </ul>
						    </div>
						</div>
					</div>
            </div>
        </div>
    </div>
    <form class="uk-form-horizontal uk-margin-large" id="cadastros_almo">
    <div class="uk-card-body">
    		<div class="uk-margin">
    			<label class="uk-form-label" for="form-horizontal-text">Nome do Produto</label>
			        <div class="uk-form-controls">
			            <input class="uk-input" id="nome_p" type="text" placeholder="Nome do produto">
			        </div>
			    </div>

			    <div class="uk-margin">
    			<label class="uk-form-label" for="form-horizontal-text">Quantidade</label>
			        <div class="uk-form-controls">
			            <input class="uk-input" id="quantidade" type="text" placeholder="Quantidade">
			        </div>
			    </div>

			   <div class="uk-margin">
    			<label class="uk-form-label" for="form-horizontal-text">Fornecedor</label>
			        <div class="uk-form-controls">
			            <input class="uk-input" id="fonecedor1" type="text" placeholder="Fornecedor">
			        </div>
			    </div>

			     <div class="uk-margin">
    			<label class="uk-form-label" for="form-horizontal-text">Prateleira</label>
			        <div class="uk-form-controls">
			            <input class="uk-input" id="prateleira" type="text" placeholder="Prateleira">
			        </div>
			    </div>

			     <div class="uk-margin">
    			<label class="uk-form-label" for="form-horizontal-text">Notas</label>
			        <div class="uk-form-controls">
			            <input class="uk-input" id="nota1" type="text" placeholder="Notas">
			        </div>
			    </div>

			     <div class="uk-margin">
    			<label class="uk-form-label" for="form-horizontal-text"></label>
			        <div class="uk-form-controls">
			        	 <div class="uk-margin">
			        	 	<select class="uk-select" id="usado_novo">
			        	 		<option>Novo</option>
			        	 		<option>Usado</option>
			        	 	</select>
			        	 </div>
			       </div>
			       <div class="uk-margin">
	    			<label class="uk-form-label" for="form-horizontal-text">Descriçao</label>
				        <div class="uk-form-controls">
				           <textarea class="uk-textarea" rows="5" placeholder="....." id="descricao" name="desc"></textarea>
				        </div>
				    </div>
				</div>
			<div class="uk-card-footer">
				<button class="uk-button uk-button-primary" onclick="validar_cadastro_aumo()">cadastrar</button>
			</div>
		</form>
	</div>
</div>
	<footer>
		<br>
		<center><p style="color: white; display: inline;" >℗Copyright GerenciaEmpresa.com</p></center>
		<div style="color: white; float: right; margin-right: 200px; ">
			resdes socias <br><br>
			<img src="img/facebook.png" style="width: 30px; height: 30px; " uk-tooltip="title: GerenreciaMais">
			<img src="img/instagram.png" style="width: 30px; height: 30px;" uk-tooltip="title: @GerenciaSeuSistema">
			<img src="img/whatsapp.svg" style="width: 30px; height: 30px;" uk-tooltip="title: (11) 40028922">

		</div>
	</footer>
  <script type="text/javascript" src="js/uikit.min.js"></script>
  <script type="text/javascript" src="js_personalizado/validar_cadastro_ti.js"></script>
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>

</body>
</html>