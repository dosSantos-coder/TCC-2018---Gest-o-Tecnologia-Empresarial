<?php
   include("conexao.php");
    
	   $produto = $_POST['nome_p'];
	   $quantidade = $_POST['quantidade'];
	   $fornecedor = $_POST['fonecedor'];
	   $prateleira = $_POST['prateleira'];
	   $nota = $_POST['nota'];
	   $descricao = $_POST['descricao'];
	   $usado_novo =$_POST['usado_novo'];
	   
	 
          $sql = ("INSERT INTO TB_AUMOXA(PRODUTO,QUANTIDADE,USADO_NOVO,FORNCEDOR,PRATELEIRA,NOTAS,DESC_P)VALUES(?,?,?,?,?,?,?)");
          $stmt =  $con->prepare($sql);
          $stmt->bindValue(1,$produto);
          $stmt->bindValue(2,$quantidade);
          $stmt->bindValue(3,$usado_novo);
          $stmt->bindValue(4,$fornecedor);
          $stmt->bindValue(5,$prateleira);
          $stmt->bindValue(6,$nota);
          $stmt->bindValue(7,$descricao);
          $stmt->execute();

          
          
         
		  
?>