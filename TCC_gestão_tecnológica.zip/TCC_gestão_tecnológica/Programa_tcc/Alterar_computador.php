<?php
  include("conexao.php");
   session_start();

  try{
     $nome_pc = $_POST['nome_pc'];
	   $departamento = $_POST['departamento'];
	   $IP = $_POST['IP'];
	   $HD = $_POST['HD'];
	   $memoria_ram = $_POST['memoria_ram'];
	   $processador = $_POST['processador'];
	   $id = $_POST['id'];

    $query = "UPDATE  TB_CONTROLE_M SET
    NOME_PC = :nome_pc,DEPARTAMENTO = :departamento ,IP = :IP, HD = :HD ,MEMORIA=:memoria_ram,PROCESSADOR =:processador WHERE ID = :id";
    $sql = $con->prepare($query);
    $sql->bindValue(':nome_pc',$nome_pc);
    $sql->bindValue(':departamento',$departamento);
    $sql->bindValue(':IP',$IP);
    $sql->bindValue(':HD',$HD);
    $sql->bindValue(':memoria_ram',$memoria_ram);
    $sql->bindValue(':processador',$processador);
    $sql->bindValue(':id',$id);
    $sql->execute();

    header("location:Gerencia_Computadores.php");

    $_SESSION['sucesso'] = "alterado com sucesso";

	}
	  catch(Exception $e){
     echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
	  }
    die();
?>
