<!DOCTYPE html>
<html>
<head>
	<?php
	include("conexao.php");
      session_start();
	 if(!isset($_SESSION['logado'] )){
      	header("location:index.php");
      }
	?>
	<title></title>
	<link href="css/uikit.min.css" rel="stylesheet">
		<style type="text/css">
		footer {
			  background-color: rgb(0, 55, 96);
			  display: block;
			  min-height: 140px;
			  width: 100%;
		}
	</style>
</head>
<body>
	<div class="uk-section-primary uk-preserve-color">

    <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

       <nav class="uk-navbar-container" uk-navbar>
		    <div class="uk-navbar-left">

		        <ul class="uk-navbar-nav">
		            <li ><a href="Gerencia_Computadores.php">Home</a></li>
		            <li><a href="Tela_Cadastrar_pc.php">Cadastros</a></li>
		            <li class="uk-active"><a href="#">Tarefas</a></li>
		        </ul>

		    </div>
		    <div class="uk-navbar-right">

		       <ul class="uk-navbar-nav">
		            <li>
		            	<?php $not = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0");
		            	      $not->execute();
		            	      $tr = $not->rowCount();
		            	      $sql_noty = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0 ORDER BY ID DESC limit 3 "); 
                              $sql_noty->execute();?>
                              <a  href="#"><span style="margin: 3px;" class="uk-badge"><?php echo $tr; ?></span>Notificações</a>
                              <div class="uk-navbar-dropdown" style="overflow: auto;">
                              	<ul class="uk-nav uk-navbar-dropdown-nav">
                              		<?php if($tr > 0){ ?>
                              			<?php while ($linha_noty = $sql_noty->fetch()) {?>
                              				<li class="uk-nav-header">Relato</li>
					                        <li><a href="#.php"><?php echo 'ID do relato: '.$linha_noty["ID_RELATO"]."</br> Nome relator: ".$linha_noty["NOME"]." ".$linha_noty["DATA_NOTIFICAO"]." ".$linha_noty["HORA_NOTIFICAO"]; ?></a>
					                        </li>
					                    <?php }
				                    echo "<li class='uk-nav-divider'></li>
				                          <li><a href='todos_notificacao.php'>Mostrar todos Relato</a></li>";
				                }else{
				                	echo "Sem notificação novas";
				                }?>

				                    </ul>
				                </div>
				            </li>
		            <li>
		            	<a  href="#">Configurações</a>
		                <div class="uk-navbar-dropdown">
		                    <ul class="uk-nav uk-navbar-dropdown-nav">
		                        <li class="uk-active"><a href="#">configurações gerais</a></li>
		                        <li><a href="troca_senha.php">Seu perfil</a></li>
		                        <li class="uk-nav-divider"></li>
		                        <li><a href="sair.php">Sair</a></li>
		                    </ul>
		                </div>
		            </li>
		        </ul>
		    </div>
		</nav>
    </div>
    <div class="uk-section">
    	<div class="uk-container">
    		<center><h1 style="color: #fff;">Tarefas</h1></center>
    	</div>
    </div>
</div>
<nav class="uk-navbar-container uk-background-secondary  uk-panel uk-card uk-card-default uk-card-body" style="z-index: 900; height: 80px;" uk-sticky="offset: 80; bottom: #top" uk-navbar>
    <div class="uk-navbar-center">
    	<div class="uk-navbar-center-left"><div>
            <ul class="uk-navbar-nav">
                <li class="uk-active"><a href="#">Novos Casos</a></li>
                
            </ul>
        </div>
    </div>
     <div class="uk-navbar"><div>
            <ul class="uk-navbar-nav">
                <li><a href="meus_relatos.php">Meus casos</a></li>
            </ul>
        </div>
    </div>
        <div class="uk-navbar-center-right">
        <div>
        <div>
            <ul class="uk-navbar-nav">
                <li><a href="casos_resolvidos.php">casos resolvidos</a></li>
            </ul>
        </div>
            <ul class="uk-navbar-nav">
                <li><a href="todos_relatos.php" >Todos os casos</a></li>
            </ul>
        </div>
    </div>
   </div>
    <div class="uk-navbar-left">

        

    </div>
 </nav>
 
    <div class="uk-background-default uk-padding">
        	<div class="uk-overflow-auto">
        		<h3 style="display: inline;">Novos relatos</h3>
        	<?php 
                 $cont_erro = $con->prepare("SELECT * FROM TB_OS where RELATO_PEGO = 0 ");
                 $cont_erro->execute();
                                 
        	?>
        		<span class="uk-badge" style="margin-top: -6px;"><?php echo $cont_erro->rowCount();?></span>

        	<table class="uk-table  uk-table-divider">
						<thead>
							<tr class="">
								<th class="column1">Data e Hora</th>
								<th class="column2">ID</th>
								<th class="column3">Nome</th>
								<th class="column4">Departamento</th>
								<th class="column5">Gravidade</th>
								<th class="column6">Frequecia</th>
								<th class="column7">Ramal</th>
								<th class="column8">Data atulizada</th>
								<th class="column9">Hora atualizada</th>
								<th class="column10">informacoes</th>
							</tr>
						</thead>
					<?php
						 $pagina_atual =  filter_input(INPUT_GET,'pagina_erro',
                                  FILTER_SANITIZE_NUMBER_INT);
                                 $pagina = (!empty($pagina_atual)) ? $pagina_atual : 1;
                                 $quanti_result_pg = 10;

                                 $inicio = ($quanti_result_pg * $pagina) - $quanti_result_pg;

                                  $sql_erro = $con->prepare("SELECT * FROM TB_OS where RELATO_PEGO = 0 order by  ID desc LIMIT $inicio,$quanti_result_pg ");
                                  $sql_erro->execute();
                                  $relatoRow = $sql_erro->rowCount();
                                  
                                   
                       if($relatoRow == 0 ){
		                          echo  '<center><h2>Sem nem um relato a Resolver</h2></center>';
		                        }
		                        while ($linha_erro = $sql_erro->fetch()) {?>
						<tbody>
								<tr>

									<td class="column1"><?php echo $linha_erro['DATA_ENVIO'];?> <?php echo $linha_erro['HORA_ENVIO'] ?></td>
									<td class="column2"><?php echo $linha_erro['ID'];?></td>
									<td class="column3"><?php echo $linha_erro['NOME_MANDO']; ?></td>
									<td class="column4"><?php echo $linha_erro['DEPARTAMENTO'] ?></td>
									<td class="column5"><?php echo $linha_erro['GRAVIDADE'] ?></td>
									<td class="column6"><?php echo $linha_erro['FREQUECIA'];?></td>
									<td class="column7"><?php echo $linha_erro['RAMAL'];?></td>
									<td class="column8"><?php echo $linha_erro['DATA_ATUALIZACAO'];?></td>
									<td class="column9"><?php echo $linha_erro['HORA_ENVIO'] ?></td>
                                    <td class="column10">
                                    	<button class="uk-button uk-button-default uk-margin-small-right" type="button" uk-toggle="target: #modal-info<?php echo $linha_erro['ID'];?>">Informacoes</button>

										<div id="modal-info<?php echo $linha_erro['ID'];?>" uk-modal>
										    <div class="uk-modal-dialog uk-modal-body">
										    	<button class="uk-modal-close-default" type="button" uk-close></button>
										        <h2 class="uk-modal-title">Informacoes</h2>
										        <center><p style="display: inline;">Titulo: </p><?php echo $linha_erro['TITULO']; ?></center>
                                                <div >
                                                   <p style="display: inline;">Descrição: </p><?php echo $linha_erro['DESCRICAO']; ?>
                                               </div><br><br>
                                               <form method="POST" action="adicionar_relato.php">
                                               	<hr class="uk-divider-icon">
                                                 <p class="uk-text-right">
										        	<input type="hidden" name="id_mando" value="<?php echo $linha_erro['ID_MANDO'];?>">
										        	<input type="hidden" name="id_pessoa" value="<?php echo $_SESSION['ID']; ?>" id="id_pessoa">
										        	<input type="hidden" name="nome" value="<?php echo $_SESSION['nome']; ?>" id="id_pessoa">
                                                    <input type="hidden" name="id_relato" id="id_erro" value ="<?php echo $linha_erro['ID'];?>">
										            <input  name=""class="uk-button uk-button-primary" type="submit" value="Resolver" style="float: right; display: inline; width: 100%;">
										       </form>
										   </p>
										</div>
									</div>
								</td>
							</tr>
						</tbody>
						  <?php }?>
					</table>
				</div>
			</div>
		
	 <?php $r_pg = $con->prepare("SELECT COUNT(ID) AS NUM_ROWS FROM TB_OS WHERE RELATO_PEGO = 0  ");
                                 $r_pg->execute();
                                 $row_erro = $r_pg->fetch();
                                 $q_pg_erro = ceil($row_erro['NUM_ROWS'] / $quanti_result_pg );
                                 $max_links = 5;  ?>
                                 <ul class="uk-pagination uk-flex-center" uk-margin>
								    <li><a class="page-link" href="novos_relatos.php?pagina_erro=1"><span uk-pagination-previous></span></a></li><?php for($pagina_ant = $pagina - $max_links; $pagina_ant <= $pagina - 1; $pagina_ant++){
                                      if($pagina_ant >=1){
                                      ?></li>
								    <li><a class="page-link" href="novos_relatos.php?pagina_erro=<?php echo $pagina_ant;?>"><?php echo $pagina_ant;?></a></li>
								    <li>
								    <?php }}?>
								    <li><a class="page-link" href="novos_relatos.php?pagina_erro=<?php echo $pagina;?>"><?php echo $pagina;?></a></li>
								     <?php for($pg_dps = $pagina + 1; $pg_dps <= $pagina + $max_links; $pg_dps++){
                                      if($pg_dps <= $q_pg_erro){
                                      ?>
								    <li> <a class="page-link" href="novos_relatos.php?pagina_erro=<?php echo $pg_dps;?>"><?php echo $pg_dps;?></a></li>
								    <?php }}?>
								    <li> <a class="page-link" href="novos_relatos.php?pagina_erro=<?php echo $q_pg_erro;?>"><span uk-pagination-next></span></a></li>
								</ul>
								<br><br>
								<footer>
									<br>
									<center><p style="color: white; display: inline;" >℗Copyright GerenciaEmpresa.com</p></center>
									<div style="color: white; float: right; margin-right: 200px; ">
										resdes socias <br><br>
										<img src="img/facebook.png" style="width: 30px; height: 30px; " uk-tooltip="title: GerenreciaMais">
										<img src="img/instagram.png" style="width: 30px; height: 30px;" uk-tooltip="title: @GerenciaSeuSistema">
										<img src="img/whatsapp.svg" style="width: 30px; height: 30px;" uk-tooltip="title: (11) 40028922">

									</div>
								</footer>
	
 <script type="text/javascript" src="js/uikit.min.js"></script>
</body>
</html>