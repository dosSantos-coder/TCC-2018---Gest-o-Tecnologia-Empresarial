<!DOCTYPE html>
<html>
<head>
	<?php
	include("conexao.php");
      session_start();
      if(!isset($_SESSION['logado'] )){
      	header("location:index.php");
      }
	?>
	<title>Gerenciar software</title>
	<link href="css/uikit.min.css" rel="stylesheet">
	<style>
		  #excluir:hover{
				 background: red;
				 color: #fff;
			 }
		   #hove:hover{
			   	background:#4d94ff;
			   	color: #fff;
		   }
		   footer {
	  background-color: rgb(0, 55, 96);
	  display: block;
	  min-height: 140px;
	  width: 100%;
}
	</style>
</head>
<body>
	<div class="uk-section-primary uk-preserve-color">

    <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

       <nav class="uk-navbar-container" uk-navbar>
		    <div class="uk-navbar-left">

		        <ul class="uk-navbar-nav">
		            <li class="uk-active"><a href="#">Home</a></li>
		            <li><a href="Tela_Cadastrar_pc.php">Cadastros</a></li>
		            <li><a href="novos_relatos.php">Tarefas</a></li>
		        </ul>

		    </div>
		    <div class="uk-navbar-center">
		     <br>
		     		<h4>Olá <?php echo $_SESSION["nome"]." ".$_SESSION['sobrenome'];?></h4>
		     	
		     </div>
		    <div class="uk-navbar-right">

		       <ul class="uk-navbar-nav">
		            <li>
		            	<?php $not = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0");
		            	      $not->execute();
		            	      $tr = $not->rowCount();
		            	      $sql_noty = $con->prepare("SELECT * FROM NOTIFICACAO WHERE VIZUALIZAR = 0 ORDER BY ID DESC limit 3 "); 
                              $sql_noty->execute();?>
                              <a  href="#"><span style="margin: 3px;" class="uk-badge"><?php echo $tr; ?></span>Notificações</a>
                              <div class="uk-navbar-dropdown" style="overflow: auto;">
                              	<ul class="uk-nav uk-navbar-dropdown-nav">
                              		<?php if($tr > 0){ ?>
                              			<?php while ($linha_noty = $sql_noty->fetch()) {?>
                              				<li class="uk-nav-header">Relato</li>
					                        <li><a href="novos_relatos.php"><?php echo 'ID do relato: '.$linha_noty["ID_RELATO"]."</br> Nome relator: ".$linha_noty["NOME"]." ".$linha_noty["DATA_NOTIFICAO"]." ".$linha_noty["HORA_NOTIFICAO"]; ?></a>
					                        </li>
					                    <?php }
				                    echo "<li class='uk-nav-divider'></li>
				                          <li><a href='todos_notificacao.php'>Mostrar todos Relato</a></li>";
				                }else{
				                	echo "Sem notificação novas";
				                }?>

				                    </ul>
				                </div>
				            </li>
		            <li>
		            	<a  href="#">Configurações</a>
		                <div class="uk-navbar-dropdown">
		                    <ul class="uk-nav uk-navbar-dropdown-nav">
		                        <li class="uk-active"><a href="#">configurações gerais</a></li>
		                        <li><a href="troca_senha.php">Seu perfil</a></li>
		                        <li class="uk-nav-divider"></li>
		                        <li><a href="sair.php">Sair</a></li>
		                    </ul>
		                </div>
		            </li>
		        </ul>
		    </div>
		</nav>
    </div>
    <div class="uk-section">
    	<div class="uk-container">
    		<center><h1 style="color: #fff;">Gerenciamento</h1></center>
    	</div>
    </div>
</div>
<nav class=" uk-navbar-container uk-background-secondary  uk-panel" style="z-index: 900; height: 80px;" uk-sticky="offset: 80; bottom: #top" uk-navbar>
    <div class="uk-navbar-center">
    	<div class="uk-navbar-center-left"><div>
            <ul class="uk-navbar-nav">
                <li><a href="Gerencia_Computadores.php">Computadores</a></li>
                
            </ul>
        </div>
    </div>
     <div class="uk-navbar"><div>
            <ul class="uk-navbar-nav">
                <li class="uk-active"><a href="#">Software</a></li>
            </ul>
        </div>
    </div>
        <div class="uk-navbar-center-right"><div>
            <ul class="uk-navbar-nav">
                <li><a href="Gerencia_Almoxarifado.php">Almoxarifado</a></li>
            </ul>
        </div>
    </div>

    </div>
</nav>
   <div>
	<div class="uk-background-default uk-padding">
		<div class="uk-overflow-auto">
			<table class="uk-table  uk-table-middle uk-table-divider">
				<div>
					<h3 style="display: inline;">Software</h3>
        				<span class="uk-badge" style="margin-top: -6px;">
        					<?php
        					$quentidade_s = $con->prepare("SELECT * FROM TB_SOFTWARE");
        					$quentidade_s->execute();
        					echo $quentidade_s->rowCount();
        					?>
        				</span>
        				<div class="uk-align-right">
        						<!-- mostra notificacao de alteracao -->
        						<?php if(isset($_SESSION["sucesso"])){
        							echo
        							'<div class="uk-alert-success" style ="width:400px;" uk-alert>
        							      <a class="uk-alert-close" uk-close></a>
        							       <p>'.$_SESSION['sucesso'].'</p>
        							</div>';
        						   	unset($_SESSION['sucesso']);
        						 }
							   if(isset($_SESSION['sucesso_ex'])){
									 echo
									 '<div class="uk-alert-success" style ="width:400px;" uk-alert>
									 			<a class="uk-alert-close" uk-close></a>
									 			 <p>'.$_SESSION['sucesso_ex'].'</p>
									 </div>';
									 	unset($_SESSION['sucesso_ex']);
									 }
							 ?>
        					</div>
        				</div>
				<thead>
		            <tr>
		                <th>Nome do Software</th>
		                <th>Fornecedor</th>
		                 <th>infomacoes</th>
		                <th>alterar</th>
		                <th>excluir</th>
		                
		            </tr>
		        </thead>
		         <?php $query_S = $con->prepare("SELECT * FROM TB_SOFTWARE");
			      	      $query_S->execute();
			      	      while ($linha_software = $query_S->fetch()) {?>
		        <tbody>
		            <tr>
		            	<td><?php echo $linha_software['NOME_VERSAO'];?></td>
		            	<td><?php echo $linha_software['FORNECEDOR'];?></td>
		            	<td>
							<button class="uk-button uk-button-default uk-margin-small-right" type="button" uk-toggle="target: #modal-info<?php $linha_software['ID'];?>" id= "hove">Informaçoes</button>
							<div id="modal-info<?php $linha_software['ID'];?>" uk-modal>
							    <div class="uk-modal-dialog uk-modal-body">
							        <button class="uk-modal-close-outside" type="button" uk-close></button>
							      
							        <h2 class="uk-modal-title">Informaçoes do Programa</h2>
							        <h4 style="display: inline;">Nome do software:</h4> <p style="display: inline;"><?php echo $linha_software['NOME_VERSAO']; ?></p><br>
							        <h4 style="display: inline;">Fornecedor:</h4> <p style="display: inline;"><?php echo $linha_software['FORNECEDOR']; ?></p><br>
							        <h4 style="display: inline;">Plataforma:</h4> <p style="display: inline;"><?php echo $linha_software['PLATAFOMA']; ?></p><br>
							        <h4 style="display: inline;">Chave do Produto:</h4> <p style="display: inline;"><?php echo $linha_software['CHAVE_PRODUTO']; ?></p><br>
							        <h4 style="display: inline;">Data da compra:</h4> <p style="display: inline;"><?php echo $linha_software['DATA_COMPRA']; ?></p><br>
							         <h4 style="display: inline;">Nota fiscal:</h4> <p style="display: inline;"><?php echo $linha_software['NOTA_FISCAL']; ?></p><br>


							        
							    </div>
							</div>
		            	</td>
			            <td><a class="uk-button uk-button-default" href="#modal-alterar<?php echo $linha_software['ID']; ?>" uk-toggle id="hove">Alterar</a>
				            	<div id="modal-alterar<?php echo $linha_software['ID']; ?>" uk-modal>
								    <div class="uk-modal-dialog">
								    	<button class="uk-modal-close-default" type="button" uk-close></button>
								    	<div class="uk-modal-header">
								            <h2 class="uk-modal-title">Alterar</h2>
								        </div>
								        <div class="uk-modal-body" uk-overflow-auto>
								        	<form class="uk-form-stacked" action="alterar_sotware.php" method="POST">
								        		<input type="hidden"  name="id_software" id="<?php $linha_software['ID'];?>" value ="<?php echo $linha_software['ID'];?>">
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Nome da versao</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="nome_v" type="text" value="<?php echo $linha_software['NOME_VERSAO']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Fornecedor</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="fonecedor" type="text" value="<?php echo $linha_software['FORNECEDOR']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Plataforma</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="Plataforna" type="text" value="<?php echo $linha_software['PLATAFOMA']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Chave do produto</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="chave_produto" type="text" value="<?php echo $linha_software['CHAVE_PRODUTO']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Data da compra</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="data_compra" type="text" value="<?php echo $linha_software['DATA_COMPRA']; ?>">
								        		   </div>
								        		</div>
								        		<div class="uk-margin">
								        			<label class="uk-form-label" for="form-stacked-text">Nota fiscal</label>
								        			<div class="uk-form-controls">
								        				<input class="uk-input" name="NOTA_FISCAL" type="text" value="<?php echo $linha_software['NOTA_FISCAL']; ?>">
								        		   </div>
								        		</div>
								        	</div>
								        	<div class="uk-modal-footer uk-text-right">
								        		<button class="uk-button uk-button-default uk-modal-close" type="button">Cancelar</button>
								        		<input type="submit" name="" class="uk-button uk-button-primary" value="alterar">
								        	</div>
								        </form>

								    </td>
								     <td>
								    	<a class="uk-button uk-button-default" href="#modal-excluir<?php echo $linha_software['ID']; ?>" id="excluir" uk-toggle>Excluir</a>
								    	<div id="modal-excluir<?php echo $linha_software['ID']; ?>" uk-modal>
								    		<div class="uk-modal-dialog">
										        <button class="uk-modal-close-default" type="button" uk-close></button>
										        <div class="uk-modal-header" style="background-color: red;">
										            <h2 class="uk-modal-title" style="color: #fff;">Tem certeza que dejesa excluir</h2>
										        </div>
										        <div class="uk-modal-body">
										        	<center>
										        		<form action="Excluir_Software.php" method="POST">
										        		<input type="hidden"  name="id" id="<?php $linha_software['ID'];?>" value ="<?php echo $linha_software['ID'];?>">
											        	<button class="uk-button uk-button-Secondary uk-modal-close uk-button-large uk-width-1-3" type="button">Cancelar</button>
											            <button class="uk-button uk-button-primary uk-button-large uk-width-1-3" type="submit">Excluir</button>
											        </center>
										        </div>
										       </form>
										    </div>
										</div>
								    </td>
								</td>
							</tr>
		        <?php }?>
		        </tbody>
		    </table>
		</div>
	</div>
</div>
<footer>
	<br>
			<center><p style="color: white; display: inline;" >℗Copyright GerenciaEmpresa.com</p></center>
			<div style="color: white; float: right; margin-right: 200px; ">
				resdes socias <br><br>
				<img src="img/facebook.png" style="width: 30px; height: 30px; " uk-tooltip="title: GerenreciaMais">
				<img src="img/instagram.png" style="width: 30px; height: 30px;" uk-tooltip="title: @GerenciaSeuSistema">
				<img src="img/whatsapp.svg" style="width: 30px; height: 30px;" uk-tooltip="title: (11) 40028922">

			</div>
</footer>
   <script type="text/javascript" src="js/uikit.min.js"></script>
</body>
</html>
