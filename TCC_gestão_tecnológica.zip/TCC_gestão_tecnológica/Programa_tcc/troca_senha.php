<!DOCTYPE html>
<html>
<head>
	<title>Trocar senha</title>
	<link href="css/uikit.min.css" rel="stylesheet">
	<?php  include("conexao.php"); 
           session_start();
           $id = $_SESSION['ID'] 
	?>
</head>
<body>
<div class="uk-card uk-card-primary uk-card-body">
            <h3 class="uk-card-title">Informaçoes do usúario</h3><button class="uk-button uk-button-default " onclick="goBack()" style="float:right; margin-top: 0px;">Voltar</button>
           
			
				        
				    	
        </div><br>
       <center>
        <div class="uk-card uk-card-default uk-width-1-2@m">
			    <div class="uk-card-header">
			        <div class="uk-grid-small uk-flex-middle" uk-grid>
			            <div class="uk-width-expand">
			                <h3 class="uk-card-title uk-margin-remove-bottom">Seu perfil</h3>
			            </div>
			        </div>
			    </div>
			    <div class="uk-card-body">
			       <?php
							$funcionario = $con->prepare("SELECT * FROM TB_FUNCIONARIO where ID = '$id'");
							$funcionario->execute();
				    		while ($linha_fun = $funcionario->fetch()) {
				    			?>
				    			<h2 style="display: inline;">Nome: </h2><h3 style=" display: inline; color: ;"><?php echo $linha_fun['NOME']." ".$linha_fun['SOBRENOME']; ?> </h3><br>
				    			<h2 style="display: inline;">Email: </h2><h3 style=" display: inline; color: ;"><?php echo $linha_fun['EMAIL'] ?> </h3><br>
				    			<h2 style="display: inline;">senha: </h2><h3 style=" display: inline; color: ; ">*****************</h3><br>

				    			<h2 style="display: inline; ">Idade: </h2> <h3 style="display: inline; color: ;"><?php echo $linha_fun['IDADE']; ?> </h3>
				    			<br>
				    			<h2 style="display: inline; ">Setor: </h2><h3 style="display: inline; color: ;"> <?php  if($linha_fun['TIPO'] == 0){
				    				echo "TECNICO EM INFORMÁTICA";
				    			}if($linha_fun['TIPO'] == 1){
				    				echo "funcionário";
				    			} if($linha_fun['TIPO'] == 2){
				    				echo "adm";
				    			} ?></h3>
		    			   <?php }?>
		    			</div>
			    <div class="uk-card-footer">
			    </div>
			</div>
</center>
	   <script type="text/javascript">
	   	function goBack() {
		    window.history.back()
	   	} 
        function solicitar_senha(){

        	$.ajax("")

        }
	</script>
   <script type="text/javascript" src="js/uikit.min.js"></script>
   <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
</body>
</html>