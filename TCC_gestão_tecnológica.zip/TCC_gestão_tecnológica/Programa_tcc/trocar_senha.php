<?php

  include("conexao.php");
  session_start();
  $email = $_POST['email'];
  $novaS = $_POST['senhaa'];
    
  if($novaS != ""){
     $sql = $con->prepare("SELECT ID FROM TB_FUNCIONARIO WHERE EMAIL = '$email'");
     $sql->execute();

    $r  = $sql->fetch();
    $id =  $r['ID'];

    $mudar_senha = $con->prepare("UPDATE TB_FUNCIONARIO SET FST_ACESSO = 1 , SENHA = :senhaV WHERE ID = :id");
    $mudar_senha->bindValue("senhaV",$novaS);
    $mudar_senha->bindValue("id",$id);
    $mudar_senha->execute();

  echo "Senha_atualizada";
  }else{
  	echo "novaS_vazio";
  }
   


     ?>