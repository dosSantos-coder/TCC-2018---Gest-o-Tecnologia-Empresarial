<?php
	include("conexao.php");
     session_start();

try{
     $nome_versao = $_POST['nome_v'];
     $fornecedo = $_POST['fonecedor'];
     $plataforma = $_POST['Plataforna'];
     $chave_p = $_POST['chave_produto'];
     $quantidade = $_POST['quantidade'];
     $data_compra = $_POST['data_compra'];
     $nota_f =$_POST['NOTA_FISCAL'];
     $ID = $_POST['id_software'];

     $sql =" update TB_SOFTWARE set CHAVE_PRODUTO = :chave_p, QUANTIDADE_LICENCA = :quantidade , PLATAFOMA = :plataforma ,NOTA_FISCAL = :nota_f ,DATA_COMPRA = :data_compra , NOME_VERSAO = :nome_versao , FORNECEDOR = :fornecedo WHERE  ID = :ID";
     $query = $con->prepare($sql);
     $query->bindValue(':chave_p',$chave_p);
     $query->bindValue(':quantidade',$quantidade);
     $query->bindValue(':plataforma',$plataforma);
     $query->bindValue(':nota_f',$nota_f);
     $query->bindValue(':data_compra',$data_compra);
     $query->bindValue(':nome_versao',$nome_versao);
     $query->bindValue(':fornecedo',$fornecedo);
     $query->bindValue(':ID',$ID);
     $query->execute();

  
     header("location: Gerencia_Software.php");
     $_SESSION['sucesso'] = "Alterado com sucesso";
}
catch(Exception $e){
          echo 'algum erro foi encontrado tente mais tarde:',  $e->getMessage();
      }
      die();
?>

